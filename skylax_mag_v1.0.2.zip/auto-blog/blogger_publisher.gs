/**
 * Skylax Mag — Blogger Publisher
 *
 * Publishes posts to Blogger using the Blogger Advanced Service.
 * Handles OAuth2 authentication, post creation, and image handling.
 */

/**
 * Initialize the Blogger Advanced Service.
 * Run this ONCE from the Apps Script editor after enabling the Blogger API.
 *
 * Steps:
 * 1. Go to Services (+) in Apps Script editor
 * 2. Add "Blogger API v3"
 * 3. Run this function to authorize
 */
function setupBlogger() {
  var blog = Blogger.Blogs.get(CONFIG.BLOG_ID);
  Logger.log('Blog connected: ' + blog.name);
  Logger.log('Blog URL: ' + blog.url);
  Logger.log('Total posts: ' + blog.posts.totalItems);
  return blog;
}

/**
 * Publish a post to Blogger.
 *
 * @param {string} title - Post title
 * @param {string} htmlContent - HTML body content
 * @param {Array} labels - Array of label strings
 * @param {string} imageUrl - Featured image URL (optional)
 * @returns {Object} { success, postUrl, postId, error }
 */
function publishPost(title, htmlContent, labels, imageUrl) {
  // Dry run check
  if (CONFIG.DRY_RUN) {
    Logger.log('[DRY RUN] Would publish: ' + title);
    Logger.log('[DRY RUN] Labels: ' + labels.join(', '));
    return {
      success: true,
      postUrl: '(dry run)',
      postId: '(dry run)',
      error: null,
      dryRun: true
    };
  }

  try {
    // Build the post body with featured image
    var body = '';
    if (imageUrl) {
      body += '<div class="post-thumbnail" style="margin-bottom:20px;">\n';
      body += '  <img src="' + imageUrl + '" alt="' + title + '" style="max-width:100%;height:auto;border-radius:8px;"/>\n';
      body += '</div>\n\n';
    }
    body += htmlContent;

    // Create the post object
    var post = {
      kind: 'blogger#post',
      blog: {
        id: CONFIG.BLOG_ID
      },
      title: title,
      content: body,
      labels: labels,
      // Publish immediately
      published: new Date().toISOString()
    };

    // Insert via Blogger Advanced Service
    var result = Blogger.Posts.insert(post, CONFIG.BLOG_ID);

    Logger.log('Published: ' + title + ' (ID: ' + result.id + ')');

    return {
      success: true,
      postUrl: result.url,
      postId: result.id,
      error: null,
      dryRun: false
    };
  } catch (e) {
    Logger.log('Publish error: ' + e.message);
    return {
      success: false,
      postUrl: null,
      postId: null,
      error: e.message,
      dryRun: false
    };
  }
}

/**
 * Publish a post using the REST API directly (fallback if Advanced Service not enabled).
 * Requires OAuth2 access token.
 *
 * @param {string} title
 * @param {string} htmlContent
 * @param {Array} labels
 * @param {string} imageUrl
 * @returns {Object} { success, postUrl, postId, error }
 */
function publishPostREST(title, htmlContent, labels, imageUrl) {
  if (CONFIG.DRY_RUN) {
    Logger.log('[DRY RUN] Would publish: ' + title);
    return { success: true, postUrl: '(dry run)', postId: '(dry run)', error: null, dryRun: true };
  }

  var accessToken = getOAuthToken();
  if (!accessToken) {
    return { success: false, postUrl: null, postId: null, error: 'No OAuth token — run setupOAuth() first', dryRun: false };
  }

  var body = '';
  if (imageUrl) {
    body += '<div class="post-thumbnail"><img src="' + imageUrl + '" alt="' + title + '"/></div>\n\n';
  }
  body += htmlContent;

  var payload = JSON.stringify({
    title: title,
    content: body,
    labels: labels
  });

  try {
    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/posts';
    var response = UrlFetchApp.fetch(url + '?key=' + getOAuthToken(), {
      method: 'post',
      contentType: 'application/json',
      payload: payload,
      headers: {
        'Authorization': 'Bearer ' + accessToken
      },
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var result = JSON.parse(response.getContentText());

    if (code === 200) {
      return { success: true, postUrl: result.url, postId: result.id, error: null, dryRun: false };
    }

    return { success: false, postUrl: null, postId: null, error: result.error ? result.error.message : 'HTTP ' + code, dryRun: false };
  } catch (e) {
    return { success: false, postUrl: null, postId: null, error: e.message, dryRun: false };
  }
}

/**
 * Get OAuth2 access token for Blogger API.
 * Uses PropertiesService for token storage.
 */
function getOAuthToken() {
  var props = PropertiesService.getUserProperties();
  return props.getProperty('BLOGGER_ACCESS_TOKEN') || '';
}

/**
 * Set OAuth2 access token.
 */
function setOAuthToken(token) {
  PropertiesService.getUserProperties().setProperty('BLOGGER_ACCESS_TOKEN', token);
}

/**
 * Get existing blog posts (for dedup checking).
 * Returns array of recent post titles and URLs.
 * @param {number} count - Number of recent posts to fetch
 */
function getRecentPosts(count) {
  try {
    var posts = Blogger.Posts.list(CONFIG.BLOG_ID, {
      maxResults: count || 20,
      orderBy: 'PUBLISHED',
      status: 'LIVE'
    });

    if (!posts.items) return [];

    return posts.items.map(function(post) {
      return {
        id: post.id,
        title: post.title,
        url: post.url,
        published: post.published,
        labels: post.labels || []
      };
    });
  } catch (e) {
    Logger.log('Error fetching posts: ' + e.message);
    return [];
  }
}
