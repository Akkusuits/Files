/**
 * Skylax Mag — AI Auto-Blogging Configuration
 *
 * Edit the values below to configure your auto-blogging system.
 * Copy this entire project into Google Apps Script (script.google.com)
 */

const CONFIG = {

  // ─── Blogger ───────────────────────────────────────────────
  BLOG_ID: 'YOUR_BLOG_ID',           // From Blogger Settings > Publishing (long number)
  BLOG_URL: 'krishnaclinic.github.io',
  LOG_SHEET_ID: 'YOUR_GOOGLE_SHEET_ID',  // Google Sheet ID for logs

  // ─── AI Provider (Groq primary, Gemini fallback) ──────────
  GROQ_API_KEY: 'gsk_...',           // Get free key at console.groq.com
  GROQ_MODEL: 'llama-3.1-8b-instant',
  GEMINI_API_KEY: '',                 // Get free key at aistudio.google.com (fallback)
  GEMINI_MODEL: 'gemini-1.5-flash',
  AI_PROVIDER: 'auto',               // 'groq' | 'gemini' | 'auto' (auto = try groq, fallback gemini)

  // ─── Schedule ──────────────────────────────────────────────
  // Fixed presets: '1hr', '2hr', '4hr', '6hr'
  // Custom: set SCHEDULE_CUSTOM_HOURS to any number (e.g. 3, 5, 8)
  SCHEDULE_PRESETS: ['1hr', '2hr', '4hr', '6hr'],
  SCHEDULE_CUSTOM_HOURS: 0,          // Set >0 to override preset (hours between runs)
  ACTIVE_SCHEDULE: '4hr',            // Which schedule to use

  // ─── Posting Controls ──────────────────────────────────────
  MAX_POSTS_PER_RUN: 3,              // Max articles to publish per trigger
  MIN_HOURS_BETWEEN_POSTS: 2,        // Min gap between publishing posts
  DRY_RUN: false,                    // true = test without actually publishing

  // ─── RSS Sources ──────────────────────────────────────────
  SOURCES: [
    { name: 'BBC Sport',     url: 'http://feeds.bbci.co.uk/sport/football/rss.xml',  enabled: true },
    { name: 'Guardian',      url: 'https://www.theguardian.com/football/rss',         enabled: true },
    { name: 'Sky Sports',    url: 'http://www.skysports.com/rss/12040',              enabled: true }
  ],

  // ─── Label Categories (enable/disable for auto-posting) ───
  // Set enabled: false to skip articles that only match that category
  LABELS: {
    'news':            { enabled: true,  keywords: ['news','announce','report','update','reveal','declare','statement'] },
    'transfers':       { enabled: true,  keywords: ['transfer','signing','deal','bid','move','loan','contract','agree','fee','purchase'] },
    'fixtures':        { enabled: true,  keywords: ['fixture','schedule','kickoff','matchday','draw','calendar','reschedule'] },
    'teams':           { enabled: true,  keywords: ['club','team','squad','manager','coach','lineup','roster','session'] },
    'players':         { enabled: true,  keywords: ['player','striker','midfielder','goalkeeper','defender','winger','captain'] },
    'world-cup-2026':  { enabled: true,  keywords: ['world cup','fifa 2026','host city','qualification','qualifier','concacaf','uefa','copa'] },
    'match-reports':   { enabled: true,  keywords: ['match','result','score','goals','victory','defeat','win','loss','draw','stalemate'] },
    'tactics':         { enabled: true,  keywords: ['formation','tactic','strategy','pressing','counter-attack','possession','press'] },
    'standings':       { enabled: true,  keywords: ['table','standings','points','league position','ranking','top','bottom','relegation'] },
    'highlights':      { enabled: true,  keywords: ['highlight','video','goal of the week','compilation','best goals','save'] }
  },

  // ─── AI Rewrite Prompt ─────────────────────────────────────
  AI_PROMPT: `You are a senior football journalist writing for Skylax Mag, a FIFA World Cup 2026 blog.

Rewrite the following article in your own unique voice. Be engaging, informative, and add expert analysis.
Keep it 300-500 words. Use HTML formatting: <p> for paragraphs, <h2> for subheadings, <strong> for emphasis, <ul>/<li> for lists.

Rules:
- Create a fresh perspective — do NOT copy the original
- Add your own insights and analysis
- Write in an authoritative but accessible tone
- Include relevant statistics or quotes when available
- End with a forward-looking statement or question

Title: {title}
Content: {content}`
};

/**
 * Get the active schedule interval in hours.
 * Returns custom hours if set, otherwise resolves preset.
 */
function getIntervalHours() {
  if (CONFIG.SCHEDULE_CUSTOM_HOURS > 0) {
    return CONFIG.SCHEDULE_CUSTOM_HOURS;
  }
  var presetMap = {
    '1hr': 1,
    '2hr': 2,
    '4hr': 4,
    '6hr': 6
  };
  return presetMap[CONFIG.ACTIVE_SCHEDULE] || 4;
}

/**
 * Get enabled labels only (where enabled: true).
 */
function getEnabledLabels() {
  var enabled = {};
  for (var label in CONFIG.LABELS) {
    if (CONFIG.LABELS[label].enabled) {
      enabled[label] = CONFIG.LABELS[label];
    }
  }
  return enabled;
}

/**
 * Get enabled RSS sources only.
 */
function getEnabledSources() {
  return CONFIG.SOURCES.filter(function(s) { return s.enabled; });
}
