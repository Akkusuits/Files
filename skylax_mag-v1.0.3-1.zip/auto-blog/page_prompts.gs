/**
 * Skylax Mag — Page AI Prompts
 *
 * Specialized prompts for each auto-updating Blogger page.
 * Each prompt instructs the AI to extract structured data from
 * recent news articles and format it as HTML content.
 */

function getPagePrompt(pageKey) {
  var prompts = {

    // ─── Schedule Page ──────────────────────────────────────
    'schedule': `You are a football data analyst writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile the most up-to-date FIFA World Cup 2026 match schedule.

Write a comprehensive, well-organized HTML page with:

1. GROUP STAGE SCHEDULE
   - List all 12 groups (A through L) with their teams
   - For each group, show all matchdays with: date, time (ET), teams, venue, city
   - Group matches: June 11 – June 27, 2026

2. KNOCKOUT STAGE SCHEDULE
   - Round of 32: June 29 – July 2
   - Round of 16: July 3 – July 5
   - Quarter-finals: July 9 – July 10
   - Semi-finals: July 14 – July 15
   - Third-place match: July 18
   - Final: July 19 at MetLife Stadium, East Rutherford, NJ

3. KEY DATES
   - Opening match: June 11, 2026 (Mexico City)
   - Final: July 19, 2026 (MetLife Stadium)

Use HTML tables for the schedule. Include venue and city for each match.
Style: <h2> for sections, <h3> for groups, <table> for schedules, <strong> for team names.
Add a "Last Updated" note at the bottom with today's date.
No AI-sounding language. Write like a real sports data page.`,

    // ─── Standings Page ─────────────────────────────────────
    'standings': `You are a football data analyst writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile the current FIFA World Cup 2026 group standings.

Write a comprehensive HTML page with:

1. GROUP STANDINGS
   - For each group (A through L), show a standings table with columns:
     Team | P | W | D | L | GF | GA | GD | Pts
   - Teams should be ordered by points (descending), then goal difference, then goals for
   - If no matches have been played yet, show all teams with 0 stats and note "Tournament begins June 11, 2026"

2. QUALIFICATION STATUS
   - Mark which teams have qualified for knockout stage (top 2 from each group + 8 best 3rd-place teams)
   - Total 32 teams advance from group stage

3. GROUP SUMMARY
   - Brief note on which groups are most competitive
   - Any notable upsets or surprises

Use HTML tables for standings. Style: <h2> for sections, <h3> for groups, <table> for standings, <strong> for team names, <em> for notes.
Color-code qualification status if possible: green for qualified, yellow for still in contention, red for eliminated.
Add a "Last Updated" note at the bottom with today's date.
No AI-sounding language.`,

    // ─── Teams Page ─────────────────────────────────────────
    'teams': `You are a football analyst writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile comprehensive team profiles for the FIFA World Cup 2026.

Write a well-organized HTML page with:

1. ALL 48 QUALIFIED TEAMS
   - Group them by confederation: UEFA, CONMEBOL, CONCACAF, CAF, AFC, OFC
   - For each team show: country, FIFA ranking, group assignment, key players, manager

2. HOST NATIONS SPOTLIGHT
   - USA, Mexico, Canada — detailed profiles with venues, squads, expectations

3. TOP CONTENDERS
   - Argentina (defending champions), Brazil, France, England, Spain, Germany
   - Key players to watch, tactical strengths, weaknesses

4. DARK HORSES
   - Teams that could surprise: Morocco, Japan, South Korea, Colombia, etc.

5. SQUAD LISTS
   - For top 10 teams, list the provisional 26-man squads if available

Style: <h2> for confederations, <h3> for teams, <table> for squad lists, <strong> for player names, <ul>/<li> for bullet points.
Add a "Last Updated" note at the bottom.
No AI-sounding language. Write like a real football analyst.`,

    // ─── Stats Page ─────────────────────────────────────────
    'stats': `You are a football statistics analyst writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile the latest FIFA World Cup 2026 statistics.

Write a comprehensive HTML page with:

1. TOP SCORERS (Golden Boot Race)
   - Rank by goals scored, then assists
   - Table: Rank | Player | Country | Goals | Assists | Minutes

2. TOP ASSISTS (Golden Boot for playmakers)
   - Table: Rank | Player | Country | Assists | Goals | Minutes

3. TEAM STATS
   - Most goals scored, fewest conceded, best goal difference
   - Table: Team | Played | Won | Drawn | Lost | GF | GA | GD | Points

4. MATCH STATS
   - Highest-scoring matches
   - Biggest margins of victory
   - Clean sheets kept

5. INDIVIDUAL RECORDS
   - Fastest goals, hat-tricks, youngest/oldest scorers
   - Any record-breaking performances

6. GOALKEEPER STATS
   - Most saves, clean sheets, penalties saved

Use HTML tables for all statistics. Style: <h2> for sections, <table> for stats, <strong> for player names, <em> for notes.
Add a "Last Updated" note at the bottom.
No AI-sounding language. Write like a real sports statistics page.`,

    // ─── Results Page ───────────────────────────────────────
    'results': `You are a football match reporter writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile the latest FIFA World Cup 2026 match results.

Write a comprehensive HTML page with:

1. LATEST RESULTS
   - Most recent matches with full details
   - For each match: Date | Team 1 | Score | Team 2 | Venue | Scorers
   - Group each match by matchday

2. MATCHDAY SUMMARY
   - Key talking points from each matchday
   - Upsets, standout performances, controversial moments

3. UPCOMING FIXTURES
   - Next 5-10 matches to watch
   - Date, time, venue, what's at stake

4. HEAD-TO-HEAD RECORDS
   - For notable upcoming clashes, historical record between the teams

5. QUALIFICATION RACE
   - Which teams are through, which are still fighting
   - Scenarios for teams on the edge

Use HTML tables for results. Style: <h2> for sections, <h3> for matchdays, <table> for results, <strong> for team names, <em> for scorers.
Add a "Last Updated" note at the bottom.
No AI-sounding language. Write like a real match report page.`,

    // ─── Bracket Page ───────────────────────────────────────
    'bracket': `You are a football tournament analyst writing for Skylax Mag, a FIFA World Cup 2026 blog.

Using the recent news articles below, compile the current FIFA World Cup 2026 knockout bracket.

Write a comprehensive HTML page with:

1. BRACKET OVERVIEW
   - Visual representation of the knockout bracket
   - Show all paths from Round of 32 to the Final
   - Include team names and scores where known

2. ROUND OF 32 (June 29 - July 2)
   - All 16 matches with: Team A vs Team B, Date, Venue
   - Mark completed matches with scores

3. ROUND OF 16 (July 3 - July 5)
   - 8 matches: winners advance
   - Show confirmed matchups and TBD slots

4. QUARTER-FINALS (July 9-10)
   - 4 matches
   - Show confirmed matchups and TBD slots

5. SEMI-FINALS (July 14-15)
   - 2 matches
   - Show confirmed matchups and TBD slots

6. THIRD-PLACE MATCH (July 18)
   - Show confirmed teams and TBD

7. FINAL (July 19)
   - MetLife Stadium, East Rutherford, NJ
   - Show confirmed teams and TBD

Use HTML tables and styled divs for the bracket visualization. Color-code: green for completed, yellow for upcoming, gray for TBD.
Style: <h2> for rounds, <table> for matches, <strong> for team names, <em> for notes.
Add a "Last Updated" note at the bottom.
No AI-sounding language.`
  };

  return prompts[pageKey] || null;
}

/**
 * Fetch topic-specific RSS articles for a page type.
 * Uses the WC2026 RSS sources that match the page topic.
 */
function fetchPageArticles(pageKey) {
  var topicMap = {
    'schedule':  ['WC2026 Schedule'],
    'standings': ['WC2026 Results', 'WC2026 News'],
    'teams':     ['WC2026 Teams'],
    'stats':     ['WC2026 Results'],
    'results':   ['WC2026 Results'],
    'bracket':   ['WC2026 Results', 'WC2026 Schedule']
  };

  var sourceNames = topicMap[pageKey] || ['WC2026 News'];
  var config = loadConfig();
  var articles = [];

  config.SOURCES.forEach(function(source) {
    if (sourceNames.indexOf(source.name) !== -1 && source.enabled) {
      try {
        var fetched = fetchFeed(source);
        articles = articles.concat(fetched);
      } catch(e) {
        Logger.log('Error fetching ' + source.name + ': ' + e.message);
      }
    }
  });

  // Sort by date, take top 15 most recent
  articles.sort(function(a, b) { return b.pubDate - a.pubDate; });
  return articles.slice(0, 15);
}
