/**
 * Skylax Mag — Settings Server-Side Functions
 *
 * Provides CRUD operations for all configuration fields.
 * Used by the Settings page in the dashboard.
 */

// ─── Read Config ─────────────────────────────────────────────

/**
 * Return the full config for the Settings page UI.
 * API keys are masked for display security.
 */
function getConfigForUI() {
  var config = loadConfig();
  return {
    BLOG_ID: config.BLOG_ID,
    BLOG_URL: config.BLOG_URL,
    LOG_SHEET_ID: config.LOG_SHEET_ID,
    GROQ_API_KEY: maskKey(config.GROQ_API_KEY),
    GROQ_MODEL: config.GROQ_MODEL,
    GEMINI_API_KEY: maskKey(config.GEMINI_API_KEY),
    GEMINI_MODEL: config.GEMINI_MODEL,
    AI_PROVIDER: config.AI_PROVIDER,
    SCHEDULE_PRESETS: config.SCHEDULE_PRESETS,
    SCHEDULE_CUSTOM_HOURS: config.SCHEDULE_CUSTOM_HOURS,
    ACTIVE_SCHEDULE: config.ACTIVE_SCHEDULE,
    MAX_POSTS_PER_RUN: config.MAX_POSTS_PER_RUN,
    MIN_HOURS_BETWEEN_POSTS: config.MIN_HOURS_BETWEEN_POSTS,
    DRY_RUN: config.DRY_RUN,
    SOURCES: config.SOURCES,
    LABELS: config.LABELS,
    PAGES: config.PAGES,
    AI_PROMPT: config.AI_PROMPT
  };
}

/**
 * Mask API key for display: show first 4 and last 4 characters.
 */
function maskKey(key) {
  if (!key || key.length < 10) return key || '';
  return key.substring(0, 4) + '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022' + key.substring(key.length - 4);
}

// ─── Blog Configuration ──────────────────────────────────────

/**
 * Save basic blog configuration fields.
 */
function saveBasicConfig(formData) {
  var errors = [];
  if (!formData.BLOG_ID || !formData.BLOG_ID.trim()) {
    errors.push('Blog ID is required');
  } else if (!/^\d+$/.test(formData.BLOG_ID.trim())) {
    errors.push('Blog ID must be a numeric string');
  }
  if (!formData.BLOG_URL || !formData.BLOG_URL.trim()) {
    errors.push('Blog URL is required');
  }
  if (!formData.LOG_SHEET_ID || !formData.LOG_SHEET_ID.trim()) {
    errors.push('Log Sheet ID is required');
  }
  if (errors.length > 0) return { success: false, error: errors.join('; ') };

  var config = loadConfig();
  config.BLOG_ID = formData.BLOG_ID.trim();
  config.BLOG_URL = formData.BLOG_URL.trim();
  config.LOG_SHEET_ID = formData.LOG_SHEET_ID.trim();
  saveConfig(config);
  return { success: true, config: getConfigForUI() };
}

// ─── AI Configuration ────────────────────────────────────────

/**
 * Save AI settings. Skips masked API keys (unchanged).
 */
function saveAIConfig(formData) {
  var errors = [];
  if (!formData.AI_PROVIDER || ['groq','gemini','auto'].indexOf(formData.AI_PROVIDER) === -1) {
    errors.push('Invalid AI provider');
  }
  if (!formData.GROQ_MODEL || !formData.GROQ_MODEL.trim()) {
    errors.push('Groq model is required');
  }
  if (!formData.GEMINI_MODEL || !formData.GEMINI_MODEL.trim()) {
    errors.push('Gemini model is required');
  }
  if (!formData.AI_PROMPT || !formData.AI_PROMPT.trim()) {
    errors.push('AI prompt is required');
  } else {
    if (formData.AI_PROMPT.indexOf('{title}') === -1) {
      errors.push('AI prompt must contain {title} placeholder');
    }
    if (formData.AI_PROMPT.indexOf('{content}') === -1) {
      errors.push('AI prompt must contain {content} placeholder');
    }
  }
  if (errors.length > 0) return { success: false, error: errors.join('; ') };

  var config = loadConfig();
  config.AI_PROVIDER = formData.AI_PROVIDER;
  config.GROQ_MODEL = formData.GROQ_MODEL.trim();
  config.GEMINI_MODEL = formData.GEMINI_MODEL.trim();
  config.AI_PROMPT = formData.AI_PROMPT;

  // Only update API keys if they were changed (not masked)
  if (formData.GROQ_API_KEY && formData.GROQ_API_KEY.indexOf('\u2022') === -1) {
    config.GROQ_API_KEY = formData.GROQ_API_KEY.trim();
  }
  if (formData.GEMINI_API_KEY && formData.GEMINI_API_KEY.indexOf('\u2022') === -1) {
    config.GEMINI_API_KEY = formData.GEMINI_API_KEY.trim();
  }

  saveConfig(config);
  return { success: true, config: getConfigForUI() };
}

// ─── Schedule Configuration ──────────────────────────────────

/**
 * Save schedule settings.
 */
function saveScheduleConfig(formData) {
  var validSchedules = ['1hr','2hr','4hr','6hr'];
  if (validSchedules.indexOf(formData.ACTIVE_SCHEDULE) === -1) {
    return { success: false, error: 'Invalid schedule preset' };
  }

  var maxPerRun = parseInt(formData.MAX_POSTS_PER_RUN);
  var minGap = parseFloat(formData.MIN_HOURS_BETWEEN_POSTS);
  var customHours = parseFloat(formData.SCHEDULE_CUSTOM_HOURS);

  if (isNaN(maxPerRun) || maxPerRun < 1 || maxPerRun > 20) {
    return { success: false, error: 'Max posts must be 1\u201320' };
  }
  if (isNaN(minGap) || minGap < 0 || minGap > 24) {
    return { success: false, error: 'Min gap must be 0\u201324 hours' };
  }
  if (isNaN(customHours)) customHours = 0;
  if (customHours < 0 || customHours > 48) {
    return { success: false, error: 'Custom hours must be 0\u201348 (0 = use preset)' };
  }

  var config = loadConfig();
  config.ACTIVE_SCHEDULE = formData.ACTIVE_SCHEDULE;
  config.MAX_POSTS_PER_RUN = maxPerRun;
  config.MIN_HOURS_BETWEEN_POSTS = minGap;
  config.SCHEDULE_CUSTOM_HOURS = customHours;
  config.DRY_RUN = (formData.DRY_RUN === true || formData.DRY_RUN === 'true');
  saveConfig(config);
  return { success: true, config: getConfigForUI() };
}

// ─── Sources CRUD ────────────────────────────────────────────

function addSource(name, url) {
  if (!name || !name.trim()) return { success: false, error: 'Source name is required' };
  if (!url || !url.trim()) return { success: false, error: 'RSS URL is required' };

  var config = loadConfig();
  var exists = config.SOURCES.some(function(s) {
    return s.url.toLowerCase() === url.trim().toLowerCase();
  });
  if (exists) return { success: false, error: 'A source with this URL already exists' };

  config.SOURCES.push({ name: name.trim(), url: url.trim(), enabled: true });
  saveConfig(config);
  return { success: true, sources: config.SOURCES };
}

function updateSource(index, name, url, enabled) {
  var config = loadConfig();
  if (index < 0 || index >= config.SOURCES.length) {
    return { success: false, error: 'Invalid source index' };
  }
  config.SOURCES[index] = {
    name: (name || config.SOURCES[index].name).trim(),
    url: (url || config.SOURCES[index].url).trim(),
    enabled: enabled !== undefined ? enabled : config.SOURCES[index].enabled
  };
  saveConfig(config);
  return { success: true, sources: config.SOURCES };
}

function removeSource(index) {
  var config = loadConfig();
  if (index < 0 || index >= config.SOURCES.length) {
    return { success: false, error: 'Invalid source index' };
  }
  config.SOURCES.splice(index, 1);
  saveConfig(config);
  return { success: true, sources: config.SOURCES };
}

function toggleSource(index) {
  var config = loadConfig();
  if (index < 0 || index >= config.SOURCES.length) {
    return { success: false, error: 'Invalid source index' };
  }
  config.SOURCES[index].enabled = !config.SOURCES[index].enabled;
  saveConfig(config);
  return { success: true, sources: config.SOURCES };
}

// ─── Labels CRUD ─────────────────────────────────────────────

function addLabel(name, keywords) {
  if (!name || !name.trim()) return { success: false, error: 'Label name is required' };

  var labelKey = name.trim().toLowerCase().replace(/\s+/g, '-');
  var config = loadConfig();
  if (config.LABELS[labelKey]) {
    return { success: false, error: 'A label with this name already exists' };
  }
  config.LABELS[labelKey] = {
    enabled: true,
    keywords: Array.isArray(keywords) ? keywords : []
  };
  saveConfig(config);
  return { success: true, labels: config.LABELS };
}

function updateLabel(name, data) {
  var config = loadConfig();
  if (!config.LABELS[name]) {
    return { success: false, error: 'Label not found' };
  }
  if (data.enabled !== undefined) config.LABELS[name].enabled = data.enabled;
  if (data.keywords !== undefined) config.LABELS[name].keywords = data.keywords;
  saveConfig(config);
  return { success: true, labels: config.LABELS };
}

function removeLabel(name) {
  var config = loadConfig();
  if (!config.LABELS[name]) {
    return { success: false, error: 'Label not found' };
  }
  delete config.LABELS[name];
  saveConfig(config);
  return { success: true, labels: config.LABELS };
}

function toggleLabel(name) {
  var config = loadConfig();
  if (!config.LABELS[name]) {
    return { success: false, error: 'Label not found' };
  }
  config.LABELS[name].enabled = !config.LABELS[name].enabled;
  saveConfig(config);
  return { success: true, labels: config.LABELS };
}

function saveLabels(labelsData) {
  var config = loadConfig();
  config.LABELS = labelsData;
  saveConfig(config);
  return { success: true, labels: config.LABELS };
}

// ─── Reset ───────────────────────────────────────────────────

function resetConfig() {
  saveConfig(JSON.parse(JSON.stringify(DEFAULT_CONFIG)));
  return { success: true, config: getConfigForUI() };
}

// ─── Pages Configuration ────────────────────────────────────

function savePagesConfig(pagesData) {
  var config = loadConfig();
  config.PAGES = pagesData;
  saveConfig(config);
  return { success: true, pages: config.PAGES };
}

function togglePage(key) {
  var config = loadConfig();
  var found = false;
  (config.PAGES || []).forEach(function(p) {
    if (p.key === key) {
      p.enabled = !p.enabled;
      found = true;
    }
  });
  if (!found) return { success: false, error: 'Page not found' };
  saveConfig(config);
  return { success: true, pages: config.PAGES };
}

function updatePageSetting(key, field, value) {
  var config = loadConfig();
  var found = false;
  (config.PAGES || []).forEach(function(p) {
    if (p.key === key) {
      p[field] = value;
      found = true;
    }
  });
  if (!found) return { success: false, error: 'Page not found' };
  saveConfig(config);
  return { success: true, pages: config.PAGES };
}
