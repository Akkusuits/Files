/**
 * Skylax Mag — Auto-Updating Blogger Pages
 *
 * Creates and manages static pages on the blog that auto-update
 * with the latest FIFA World Cup 2026 data: schedule, standings,
 * teams, stats, results, bracket.
 *
 * Uses the same OAuth2 tokens as blogger_publisher.gs.
 * Runs on a separate trigger (every 6 hours by default).
 */

// ─── Blogger Pages API ───────────────────────────────────────

/**
 * List all pages on the blog.
 * @returns {Array} Array of { id, title, url, updated }
 */
function listBlogPages() {
  var token = getAccessToken();
  if (!token) return [];

  try {
    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/pages?maxResults=50&status=live';
    var response = UrlFetchApp.fetch(url, {
      headers: { 'Authorization': 'Bearer ' + token },
      muteHttpExceptions: true
    });

    if (response.getResponseCode() !== 200) return [];

    var result = JSON.parse(response.getContentText());
    if (!result.items) return [];

    return result.items.map(function(page) {
      return {
        id: page.id,
        title: page.title,
        url: page.url,
        updated: page.updated
      };
    });
  } catch (e) {
    Logger.log('Error listing pages: ' + e.message);
    return [];
  }
}

/**
 * Find an existing page by title (case-insensitive).
 * @param {string} title - Page title to search for
 * @returns {Object|null} { id, title, url } or null
 */
function findPageByTitle(title) {
  var pages = listBlogPages();
  var searchTitle = title.toLowerCase();

  for (var i = 0; i < pages.length; i++) {
    if (pages[i].title.toLowerCase() === searchTitle) {
      return pages[i];
    }
  }
  return null;
}

/**
 * Create a new page on the blog.
 * @param {string} title - Page title
 * @param {string} htmlContent - HTML body content
 * @param {string} slug - URL slug
 * @returns {Object} { success, pageId, pageUrl, error }
 */
function createBlogPage(title, htmlContent, slug) {
  var token = getAccessToken();
  if (!token) {
    return { success: false, pageId: null, pageUrl: null, error: 'Not authorized' };
  }

  try {
    var payload = JSON.stringify({
      kind: 'blogger#page',
      blog: { id: CONFIG.BLOG_ID },
      title: title,
      content: htmlContent,
      status: 'live'
    });

    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/pages';
    var response = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: payload,
      headers: { 'Authorization': 'Bearer ' + token },
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var result = JSON.parse(response.getContentText());

    if (code === 200) {
      Logger.log('Created page: ' + title + ' (ID: ' + result.id + ')');
      return { success: true, pageId: result.id, pageUrl: result.url, error: null };
    }

    var errorMsg = result.error ? result.error.message : 'HTTP ' + code;
    Logger.log('Create page error: ' + errorMsg);
    return { success: false, pageId: null, pageUrl: null, error: errorMsg };
  } catch (e) {
    Logger.log('Create page error: ' + e.message);
    return { success: false, pageId: null, pageUrl: null, error: e.message };
  }
}

/**
 * Update an existing page on the blog.
 * @param {string} pageId - Page ID to update
 * @param {string} htmlContent - New HTML body content
 * @returns {Object} { success, pageUrl, error }
 */
function updateBlogPage(pageId, htmlContent) {
  var token = getAccessToken();
  if (!token) {
    return { success: false, pageUrl: null, error: 'Not authorized' };
  }

  try {
    var payload = JSON.stringify({
      kind: 'blogger#page',
      content: htmlContent
    });

    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/pages/' + pageId;
    var response = UrlFetchApp.fetch(url, {
      method: 'put',
      contentType: 'application/json',
      payload: payload,
      headers: { 'Authorization': 'Bearer ' + token },
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var result = JSON.parse(response.getContentText());

    if (code === 200) {
      Logger.log('Updated page ID: ' + pageId);
      return { success: true, pageUrl: result.url, error: null };
    }

    var errorMsg = result.error ? result.error.message : 'HTTP ' + code;
    Logger.log('Update page error: ' + errorMsg);
    return { success: false, pageUrl: null, error: errorMsg };
  } catch (e) {
    Logger.log('Update page error: ' + e.message);
    return { success: false, pageUrl: null, error: e.message };
  }
}

// ─── Page Initialization ────────────────────────────────────

/**
 * Create all configured pages on the blog (run once).
 * Skips pages that already exist (by title match).
 */
function initPages() {
  var config = loadConfig();
  var pages = config.PAGES || [];
  var created = 0;
  var skipped = 0;

  pages.forEach(function(pageConfig) {
    var existing = findPageByTitle(pageConfig.title);

    if (existing) {
      Logger.log('Page already exists: ' + pageConfig.title + ' (ID: ' + existing.id + ')');
      skipped++;
      return;
    }

    // Create placeholder content
    var placeholder = '<p>This page auto-updates with the latest FIFA World Cup 2026 ' +
      pageConfig.key + ' data. Content will appear shortly.</p>' +
      '<p><em>Last updated: ' + new Date().toLocaleString() + '</em></p>';

    var result = createBlogPage(pageConfig.title, placeholder, pageConfig.slug);

    if (result.success) {
      // Save the page ID to config for future updates
      savePageId(pageConfig.key, result.pageId);
      created++;
      Logger.log('Created: ' + pageConfig.title + ' -> ' + result.pageUrl);
    } else {
      Logger.log('Failed to create: ' + pageConfig.title + ' — ' + result.error);
    }
  });

  Logger.log('=== Pages Init Complete ===');
  Logger.log('Created: ' + created + ', Already existed: ' + skipped);
}

/**
 * Save a page ID to config for future reference.
 */
function savePageId(pageKey, pageId) {
  var props = PropertiesService.getScriptProperties();
  var pageIds = JSON.parse(props.getProperty('PAGE_IDS') || '{}');
  pageIds[pageKey] = pageId;
  props.setProperty('PAGE_IDS', JSON.stringify(pageIds));
}

/**
 * Get a saved page ID.
 */
function getPageId(pageKey) {
  var props = PropertiesService.getScriptProperties();
  var pageIds = JSON.parse(props.getProperty('PAGE_IDS') || '{}');
  return pageIds[pageKey] || null;
}

// ─── Page Content Generation ────────────────────────────────

/**
 * Generate page content using AI.
 * Fetches topic-specific articles and sends them to AI with the page prompt.
 *
 * @param {string} pageKey - Page key (schedule, standings, teams, etc.)
 * @returns {Object} { success, content, error }
 */
function generatePageContent(pageKey) {
  var prompt = getPagePrompt(pageKey);
  if (!prompt) {
    return { success: false, content: '', error: 'No prompt found for page: ' + pageKey };
  }

  // Fetch topic-specific articles
  var articles = fetchPageArticles(pageKey);

  if (articles.length === 0) {
    Logger.log('No articles found for page: ' + pageKey + ' — using prompt alone');
  }

  // Build context from articles
  var articleContext = '';
  if (articles.length > 0) {
    articleContext = '\n\n--- RECENT ARTICLES FOR REFERENCE ---\n\n';
    articles.forEach(function(article, i) {
      articleContext += 'Article ' + (i + 1) + ': ' + article.title + '\n';
      articleContext += 'Source: ' + (article.source || 'Unknown') + '\n';
      articleContext += 'Published: ' + article.pubDate.toISOString() + '\n';
      if (article.description) {
        articleContext += 'Content: ' + article.description.substring(0, 500) + '\n';
      }
      articleContext += '\n';
    });
    articleContext += '--- END ARTICLES ---\n';
  }

  // Combine prompt with article context
  var fullPrompt = prompt + articleContext;

  // Call AI
  var provider = CONFIG.AI_PROVIDER;
  var result = null;

  if (provider === 'groq' || provider === 'auto') {
    result = callGroq(fullPrompt);
    if (result.success) {
      return { success: true, content: result.content, provider: 'groq', error: null };
    }
    Logger.log('Groq failed for page ' + pageKey + ': ' + result.error);
  }

  if (provider === 'gemini' || provider === 'auto') {
    result = callGemini(fullPrompt);
    if (result.success) {
      return { success: true, content: result.content, provider: 'gemini', error: null };
    }
    Logger.log('Gemini failed for page ' + pageKey + ': ' + result.error);
  }

  return { success: false, content: '', provider: 'none', error: 'All AI providers failed' };
}

// ─── Page Update Pipeline ───────────────────────────────────

/**
 * Update a single page with fresh content.
 * @param {string} pageKey - Page key to update
 * @returns {Object} { success, title, error }
 */
function updateSinglePage(pageKey) {
  var config = loadConfig();
  var pageConfig = null;

  (config.PAGES || []).forEach(function(p) {
    if (p.key === pageKey) pageConfig = p;
  });

  if (!pageConfig) {
    return { success: false, title: pageKey, error: 'Page config not found' };
  }

  if (!pageConfig.enabled) {
    Logger.log('Page disabled, skipping: ' + pageConfig.title);
    return { success: true, title: pageConfig.title, skipped: true, error: null };
  }

  Logger.log('=== Updating Page: ' + pageConfig.title + ' ===');

  // Generate content
  var content = generatePageContent(pageKey);
  if (!content.success) {
    Logger.log('Content generation failed for: ' + pageConfig.title);
    return { success: false, title: pageConfig.title, error: content.error };
  }

  // Add footer with update timestamp
  var footer = '\n\n<hr/>\n<p style="text-align:center;color:#999;font-size:12px;">' +
    'Auto-updated by <strong>Skylax Mag</strong> | Last updated: ' +
    new Date().toLocaleString() + ' | ' +
    '<a href="' + CONFIG.BLOG_URL + '">Back to Homepage</a></p>';

  var htmlContent = content.content + footer;

  // Find or create page
  var existing = findPageByTitle(pageConfig.title);
  var pageId = getPageId(pageKey) || (existing ? existing.id : null);

  if (pageId) {
    // Update existing page
    var result = updateBlogPage(pageId, htmlContent);
    if (result.success) {
      Logger.log('Updated: ' + pageConfig.title + ' via ' + content.provider);
      return { success: true, title: pageConfig.title, error: null };
    }
    return { success: false, title: pageConfig.title, error: result.error };
  } else {
    // Create new page
    var createResult = createBlogPage(pageConfig.title, htmlContent, pageConfig.slug);
    if (createResult.success) {
      savePageId(pageKey, createResult.pageId);
      Logger.log('Created: ' + pageConfig.title + ' -> ' + createResult.pageUrl);
      return { success: true, title: pageConfig.title, error: null };
    }
    return { success: false, title: pageConfig.title, error: createResult.error };
  }
}

/**
 * Update all enabled pages with fresh content.
 * Run this on a schedule (every 6 hours recommended).
 */
function updateAllPages() {
  var config = loadConfig();
  var pages = config.PAGES || [];
  var results = [];

  Logger.log('=== Starting Page Update (' + pages.length + ' pages) ===');

  pages.forEach(function(pageConfig) {
    if (!pageConfig.enabled) {
      Logger.log('Skipping disabled page: ' + pageConfig.title);
      results.push({ key: pageConfig.key, title: pageConfig.title, success: true, skipped: true });
      return;
    }

    try {
      var result = updateSinglePage(pageConfig.key);
      results.push({ key: pageConfig.key, title: pageConfig.title, success: result.success, error: result.error });
    } catch (e) {
      Logger.log('Error updating ' + pageConfig.title + ': ' + e.message);
      results.push({ key: pageConfig.key, title: pageConfig.title, success: false, error: e.message });
    }

    // Brief pause between pages to avoid rate limiting
    Utilities.sleep(2000);
  });

  // Summary
  var succeeded = results.filter(function(r) { return r.success && !r.skipped; }).length;
  var failed = results.filter(function(r) { return !r.success; }).length;
  var skipped = results.filter(function(r) { return r.skipped; }).length;

  Logger.log('=== Page Update Complete ===');
  Logger.log('Updated: ' + succeeded + ', Failed: ' + failed + ', Skipped: ' + skipped);

  return results;
}

// ─── Dashboard Helper ───────────────────────────────────────

/**
 * Get page status data for the dashboard Settings page.
 */
function getPagesData() {
  var config = loadConfig();
  var pages = config.PAGES || [];
  var props = PropertiesService.getScriptProperties();
  var lastUpdated = JSON.parse(props.getProperty('PAGES_LAST_UPDATED') || '{}');

  return pages.map(function(p) {
    return {
      key: p.key,
      title: p.title,
      slug: p.slug,
      enabled: p.enabled,
      updateHours: p.updateHours,
      lastUpdated: lastUpdated[p.key] || null,
      pageId: getPageId(p.key)
    };
  });
}

/**
 * Update a page config field (enable/disable, change update hours).
 */
function updatePageConfig(key, field, value) {
  var config = loadConfig();
  var found = false;

  (config.PAGES || []).forEach(function(p) {
    if (p.key === key) {
      p[field] = value;
      found = true;
    }
  });

  if (!found) return { success: false, error: 'Page not found' };

  saveConfig(config);
  return { success: true, pages: getPagesData() };
}

/**
 * Trigger manual update of a specific page from dashboard.
 */
function triggerPageUpdate(pageKey) {
  var result = updateSinglePage(pageKey);

  // Record last updated time
  if (result.success) {
    var props = PropertiesService.getScriptProperties();
    var lastUpdated = JSON.parse(props.getProperty('PAGES_LAST_UPDATED') || '{}');
    lastUpdated[pageKey] = new Date().toISOString();
    props.setProperty('PAGES_LAST_UPDATED', JSON.stringify(lastUpdated));
  }

  return result;
}

/**
 * Record page update timestamp (called after updateAllPages).
 */
function recordPageUpdates(results) {
  var props = PropertiesService.getScriptProperties();
  var lastUpdated = JSON.parse(props.getProperty('PAGES_LAST_UPDATED') || '{}');

  results.forEach(function(r) {
    if (r.success && !r.skipped) {
      lastUpdated[r.key] = new Date().toISOString();
    }
  });

  props.setProperty('PAGES_LAST_UPDATED', JSON.stringify(lastUpdated));
}

/**
 * Setup trigger for page updates (separate from blog post pipeline).
 * @param {number} hours - Update interval in hours (default: 6)
 */
function setupPageUpdateTrigger(hours) {
  hours = hours || 6;

  // Remove existing page update triggers
  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (trigger.getHandlerFunction() === 'updateAllPages') {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  // Create new trigger
  ScriptApp.newTrigger('updateAllPages')
    .timeBased()
    .everyHours(hours)
    .create();

  Logger.log('Page update trigger set: every ' + hours + ' hours');
}
