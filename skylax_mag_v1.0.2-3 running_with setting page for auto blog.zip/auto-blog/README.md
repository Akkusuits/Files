# Skylax Mag — AI Auto-Blogging System

Automated football news publishing pipeline for the Skylax Mag Blogger blog (FIFA World Cup 2026).

## Architecture

```
RSS Feeds (BBC/Guardian/Sky) → Apps Script fetcher → AI Rewrite (Groq/Gemini) → Blogger API → Published Post
         ↑                                                                    ↓
    Config (Script Properties)                                    Logging (Google Sheet)
```

## Files

| File | Purpose |
|------|---------|
| `config.gs` | All settings: API keys, blog ID, schedule, sources, labels, AI prompt |
| `rss_fetcher.gs` | Fetches and parses RSS/Atom feeds (BBC Sport, Guardian, Sky Sports) |
| `ai_rewriter.gs` | AI content rewriting via Groq (primary) + Gemini (fallback) |
| `label_classifier.gs` | Keyword-based label assignment (news, transfers, fixtures, etc.) |
| `blogger_publisher.gs` | Publishes posts to Blogger via Advanced Service or REST API |
| `scheduler.gs` | Pipeline orchestrator, time-based triggers, setup wizard |
| `logger.gs` | Google Sheet logging, dedup, stats |
| `dashboard.html` | Web-based management UI |

## Quick Setup

### 1. Create Google Apps Script Project

1. Go to [script.google.com](https://script.google.com)
2. Click **New Project**
3. Rename it to "Skylax Mag Auto-Blog"

### 2. Copy Files

1. Create each `.gs` file in the Apps Script editor (File > New > Script file)
2. Copy the contents from each file in this folder
3. Create `dashboard.html` (File > New > HTML file, name it `dashboard`)

### 3. Get API Keys

**Groq (Primary AI — free):**
1. Go to [console.groq.com](https://console.groq.com)
2. Sign up / Log in
3. Create API key
4. Copy into `config.gs` → `GROQ_API_KEY`

**Gemini (Fallback AI — free):**
1. Go to [aistudio.google.com](https://aistudio.google.com)
2. Get API key
3. Copy into `config.gs` → `GEMINI_API_KEY`

### 4. Get Blogger Blog ID

1. Go to your Blogger dashboard
2. Settings > Publishing
3. Copy the Blog ID (long number in the URL)

### 5. Create Log Spreadsheet

1. Go to [sheets.google.com](https://sheets.google.com)
2. Create new spreadsheet
3. Copy the Sheet ID from the URL (the long string between `/d/` and `/edit`)
4. Paste into `config.gs` → `LOG_SHEET_ID`

### 6. Enable Blogger API

1. In Apps Script editor, click **Services** (+)
2. Add **Blogger API v3**
3. Click **Add**
4. Authorize when prompted

### 7. Run Setup

1. In Apps Script editor, select `setup` function from dropdown
2. Click **Run**
3. Follow authorization prompts
4. Check logs for success message

### 8. Configure Schedule

Edit `config.gs`:
```javascript
ACTIVE_SCHEDULE: '4hr',   // Options: '1hr', '2hr', '4hr', '6hr'
// OR for custom interval:
SCHEDULE_CUSTOM_HOURS: 3, // Any number of hours
```

Then run `setupSchedule()` from the editor.

### 9. Disable Dry Run

Once everything looks good:
```javascript
DRY_RUN: false,
```

## Schedule Options

| Preset | Interval | Posts/Day (max 3/run) |
|--------|----------|----------------------|
| `1hr` | Every 1 hour | Up to 72 |
| `2hr` | Every 2 hours | Up to 36 |
| `4hr` | Every 4 hours | Up to 18 |
| `6hr` | Every 6 hours | Up to 12 |
| Custom | Set `SCHEDULE_CUSTOM_HOURS` | Flexible |

## Category Filtering

Enable/disable categories in `config.gs`:
```javascript
LABELS: {
  'news': { enabled: true, keywords: [...] },
  'transfers': { enabled: true, keywords: [...] },
  'tactics': { enabled: false, keywords: [...] },  // Disabled — won't auto-post
}
```

## Dashboard

Access the dashboard at:
```
https://script.google.com/macros/s/{YOUR_SCRIPT_ID}/exec
```

Features:
- View publication stats (published/failed/skipped)
- Run pipeline manually
- Test with dry run mode
- View recent activity logs
- Check schedule status

## Usage

**Manual Run:**
- From editor: Select `runNow` function → Run
- From dashboard: Click "Run Now"

**Test Run (no publishing):**
- From editor: Select `testPipeline` function → Run
- From dashboard: Click "Test Run"

**View Logs:**
- Open your Google Sheet → "AutoBlog Log" tab
- Or use the dashboard

## Troubleshooting

**"No articles found"**
- RSS sources may be down
- Check if feeds are accessible in browser
- Try different sources in config

**"AI rewrite failed"**
- Check API key is valid
- Groq free tier: 30 req/min
- Falls back to Gemini automatically

**"Publish failed"**
- Check Blogger API is enabled
- Verify Blog ID is correct
- Check OAuth token is valid

**Schedule not running**
- Run `getScheduleInfo()` to check triggers
- Re-run `setupSchedule()` if needed

## Rate Limits

| Service | Free Limit | Our Usage |
|---------|-----------|-----------|
| Groq API | 30 req/min, 14,400/day | ~18/day (at 4hr) |
| Gemini API | 15 req/min, 1,500/day | Fallback only |
| Blogger API | 50,000 req/day | ~18/day |
| RSS Feeds | Unlimited | 3 feeds/run |

## License

Internal use for Skylax Mag blog. Based on free/open-source components.
