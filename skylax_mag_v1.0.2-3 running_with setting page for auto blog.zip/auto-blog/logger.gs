/**
 * Skylax Mag — Logger
 *
 * Logs auto-blogging activity to a Google Sheet.
 * Used for tracking, debugging, and dedup.
 */

/**
 * Initialize the log sheet with headers.
 * Run this once to set up the spreadsheet.
 */
function initLogSheet() {
  var sheet = getLogSheet();
  if (!sheet) return;

  // Check if headers exist
  var headers = sheet.getRange(1, 1, 1, 9).getValues()[0];
  if (headers[0] === 'Timestamp') {
    Logger.log('Log sheet already initialized');
    return;
  }

  // Set headers
  sheet.getRange(1, 1, 1, 9).setValues([[
    'Timestamp', 'Source', 'Original Title', 'Blog Title',
    'URL', 'Status', 'Labels', 'Post URL', 'Error'
  ]]);

  // Format header row
  var headerRange = sheet.getRange(1, 1, 1, 9);
  headerRange.setFontWeight('bold');
  headerRange.setBackground('#00529F');
  headerRange.setFontColor('#ffffff');

  // Set column widths
  sheet.setColumnWidth(1, 160);  // Timestamp
  sheet.setColumnWidth(2, 100);  // Source
  sheet.setColumnWidth(3, 250);  // Original Title
  sheet.setColumnWidth(4, 250);  // Blog Title
  sheet.setColumnWidth(5, 300);  // URL
  sheet.setColumnWidth(6, 80);   // Status
  sheet.setColumnWidth(7, 200);  // Labels
  sheet.setColumnWidth(8, 300);  // Post URL
  sheet.setColumnWidth(9, 200);  // Error

  Logger.log('Log sheet initialized successfully');
}

/**
 * Get or create the log sheet.
 * @returns {GoogleAppsScript.Sheets.Sheet} The log sheet
 */
function getLogSheet() {
  try {
    var ss = SpreadsheetApp.openById(CONFIG.LOG_SHEET_ID);
    var sheet = ss.getSheetByName('AutoBlog Log');

    if (!sheet) {
      sheet = ss.insertSheet('AutoBlog Log');
    }

    return sheet;
  } catch (e) {
    Logger.log('Error accessing log sheet: ' + e.message);
    return null;
  }
}

/**
 * Log a post publication attempt.
 *
 * @param {Object} data - { source, originalTitle, blogTitle, url, status, labels, postUrl, error }
 */
function logPost(data) {
  var sheet = getLogSheet();
  if (!sheet) return;

  var row = [
    new Date(),
    data.source || '',
    data.originalTitle || '',
    data.blogTitle || '',
    data.url || '',
    data.status || 'unknown',
    (data.labels || []).join(', '),
    data.postUrl || '',
    data.error || ''
  ];

  sheet.appendRow(row);

  // Color-code status
  var lastRow = sheet.getLastRow();
  var statusCell = sheet.getRange(lastRow, 6);

  switch (data.status) {
    case 'published':
      statusCell.setBackground('#c6efce').setFontColor('#006100');
      break;
    case 'failed':
      statusCell.setBackground('#ffc7ce').setFontColor('#9c0006');
      break;
    case 'skipped':
      statusCell.setBackground('#ffeb9c').setFontColor('#9c6500');
      break;
    case 'dry-run':
      statusCell.setBackground('#d9e2f3').setFontColor('#002060');
      break;
  }
}

/**
 * Check if a URL has already been processed (dedup).
 *
 * @param {string} url - The source article URL
 * @returns {boolean} True if URL was already processed
 */
function isAlreadyProcessed(url) {
  if (!url) return false;

  var sheet = getLogSheet();
  if (!sheet) return false;

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return false;

  // Get all URLs from column 5 (URL column)
  var urls = sheet.getRange(2, 5, lastRow - 1, 1).getValues();

  for (var i = 0; i < urls.length; i++) {
    if (urls[i][0] === url) return true;
  }

  return false;
}

/**
 * Check if a post was published recently (within last N hours).
 *
 * @param {number} hours - Number of hours to check
 * @returns {boolean} True if a post was published within the time window
 */
function wasRecentPost(hours) {
  var sheet = getLogSheet();
  if (!sheet) return false;

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return false;

  var cutoff = new Date(Date.now() - (hours || CONFIG.MIN_HOURS_BETWEEN_POSTS) * 60 * 60 * 1000);

  // Get timestamps and statuses from last 10 rows
  var startRow = Math.max(2, lastRow - 9);
  var data = sheet.getRange(startRow, 1, lastRow - startRow + 1, 6).getValues();

  for (var i = data.length - 1; i >= 0; i--) {
    var timestamp = new Date(data[i][0]);
    var status = data[i][5];

    if (status === 'published' && timestamp.getTime() > cutoff.getTime()) {
      return true;
    }
  }

  return false;
}

/**
 * Get recent log entries for the dashboard.
 * @param {number} count - Number of entries to return
 * @returns {Array} Array of log entry objects
 */
function getRecentLogs(count) {
  var sheet = getLogSheet();
  if (!sheet) return [];

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return [];

  var startRow = Math.max(2, lastRow - (count || 20) + 1);
  var data = sheet.getRange(startRow, 1, lastRow - startRow + 1, 9).getValues();

  return data.reverse().map(function(row) {
    return {
      timestamp: row[0],
      source: row[1],
      originalTitle: row[2],
      blogTitle: row[3],
      url: row[4],
      status: row[5],
      labels: row[6],
      postUrl: row[7],
      error: row[8]
    };
  });
}

/**
 * Get summary statistics from the log.
 * @returns {Object} Stats object
 */
function getLogStats() {
  var sheet = getLogSheet();
  if (!sheet) return { total: 0, published: 0, failed: 0, skipped: 0 };

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { total: 0, published: 0, failed: 0, skipped: 0 };

  var data = sheet.getRange(2, 6, lastRow - 1, 1).getValues();

  var stats = { total: data.length, published: 0, failed: 0, skipped: 0, 'dry-run': 0 };

  for (var i = 0; i < data.length; i++) {
    var status = data[i][0];
    if (stats.hasOwnProperty(status)) {
      stats[status]++;
    }
  }

  return stats;
}
