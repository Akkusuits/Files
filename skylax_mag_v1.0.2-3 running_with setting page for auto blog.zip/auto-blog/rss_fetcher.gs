/**
 * Skylax Mag — RSS Feed Fetcher
 *
 * Fetches and parses football news RSS feeds.
 * Returns structured article objects ready for AI rewriting.
 */

/**
 * Fetch all enabled RSS sources and return combined article list.
 * Articles are sorted by date (newest first).
 */
function fetchAllArticles() {
  var sources = getEnabledSources();
  var allArticles = [];

  for (var i = 0; i < sources.length; i++) {
    try {
      var articles = fetchFeed(sources[i]);
      allArticles = allArticles.concat(articles);
    } catch (e) {
      Logger.log('Error fetching ' + sources[i].name + ': ' + e.message);
    }
  }

  // Sort by pubDate descending (newest first)
  allArticles.sort(function(a, b) {
    return b.pubDate.getTime() - a.pubDate.getTime();
  });

  return allArticles;
}

/**
 * Fetch and parse a single RSS feed.
 * @param {Object} source - { name, url, enabled }
 * @returns {Array} Array of article objects
 */
function fetchFeed(source) {
  var response = UrlFetchApp.fetch(source.url, {
    muteHttpExceptions: true,
    followRedirects: true,
    headers: {
      'User-Agent': 'SkylaxMag-AutoBlog/1.0'
    }
  });

  if (response.getResponseCode() !== 200) {
    throw new Error('HTTP ' + response.getResponseCode() + ' for ' + source.url);
  }

  var xml = response.getContentText();
  return parseRSS(xml, source.name);
}

/**
 * Parse RSS/Atom XML into article objects.
 * Handles both RSS 2.0 and Atom formats.
 * @param {string} xmlString - Raw XML content
 * @param {string} sourceName - Name of the source for attribution
 * @returns {Array} Array of article objects
 */
function parseRSS(xmlString, sourceName) {
  var articles = [];

  try {
    var document = XmlService.parse(xmlString);
    var root = document.getRootElement();

    // Detect format: RSS 2.0 or Atom
    var namespace = root.getNamespace();
    var isAtom = root.getName() === 'feed' ||
                 (namespace && namespace.getURI().indexOf('atom') !== -1);

    if (isAtom) {
      articles = parseAtomFeed(root, sourceName);
    } else {
      articles = parseRSSFeed(root, sourceName);
    }
  } catch (e) {
    Logger.log('XML parse error for ' + sourceName + ': ' + e.message);
  }

  return articles;
}

/**
 * Parse RSS 2.0 feed.
 */
function parseRSSFeed(root, sourceName) {
  var articles = [];
  var items = root.getChildren('item');

  for (var i = 0; i < items.length; i++) {
    var item = items[i];
    var article = {
      title: getChildText(item, 'title'),
      link: getChildText(item, 'link'),
      description: stripHTML(getChildText(item, 'description')),
      pubDate: parseDate(getChildText(item, 'pubDate')),
      source: sourceName,
      thumbnail: extractThumbnailRSS(item),
      rawContent: getChildText(item, 'description') || ''
    };

    if (article.title && article.link) {
      articles.push(article);
    }
  }

  return articles;
}

/**
 * Parse Atom feed.
 */
function parseAtomFeed(root, sourceName) {
  var articles = [];
  var atomNs = XmlService.getNamespace('atom', 'http://www.w3.org/2005/Atom');
  var entries = root.getChildren('entry', atomNs);

  for (var i = 0; i < entries.length; i++) {
    var entry = entries[i];
    var link = '';
    var links = entry.getChildren('link', atomNs);
    for (var j = 0; j < links.length; j++) {
      if (links[j].getAttribute('rel') === null ||
          links[j].getAttribute('rel').getValue() === 'alternate') {
        link = links[j].getAttribute('href').getValue();
        break;
      }
    }

    var article = {
      title: getChildTextNS(entry, 'title', atomNs),
      link: link,
      description: stripHTML(getChildTextNS(entry, 'summary', atomNs) || getChildTextNS(entry, 'content', atomNs)),
      pubDate: parseDate(getChildTextNS(entry, 'published', atomNs) || getChildTextNS(entry, 'updated', atomNs)),
      source: sourceName,
      thumbnail: extractThumbnailAtom(entry, atomNs),
      rawContent: getChildTextNS(entry, 'summary', atomNs) || ''
    };

    if (article.title && article.link) {
      articles.push(article);
    }
  }

  return articles;
}

/**
 * Get text content of a child element (no namespace).
 */
function getChildText(parent, childName) {
  var child = parent.getChild(childName);
  return child ? child.getText().trim() : '';
}

/**
 * Get text content of a child element with namespace.
 */
function getChildTextNS(parent, childName, namespace) {
  var child = parent.getChild(childName, namespace);
  return child ? child.getText().trim() : '';
}

/**
 * Extract thumbnail from RSS item (media:thumbnail, enclosure, or media:content).
 */
function extractThumbnailRSS(item) {
  // Try media:thumbnail
  var mediaNs = XmlService.getNamespace('media', 'http://search.yahoo.com/mrss/');
  var thumbnail = item.getChild('thumbnail', mediaNs);
  if (thumbnail) {
    var url = thumbnail.getAttribute('url');
    if (url) return url.getValue();
  }

  // Try media:content
  var mediaContent = item.getChild('content', mediaNs);
  if (mediaContent) {
    var url2 = mediaContent.getAttribute('url');
    if (url2) return url2.getValue();
  }

  // Try enclosure
  var enclosure = item.getChild('enclosure');
  if (enclosure) {
    var url3 = enclosure.getAttribute('url');
    if (url3) return url3.getValue();
  }

  // Try extracting from description HTML
  var desc = getChildText(item, 'description') || getChildText(item, 'content:encoded');
  var imgMatch = desc.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (imgMatch) return imgMatch[1];

  return '';
}

/**
 * Extract thumbnail from Atom entry.
 */
function extractThumbnailAtom(entry, atomNs) {
  var mediaNs = XmlService.getNamespace('media', 'http://search.yahoo.com/mrss/');

  // Try media:thumbnail
  var thumbnail = entry.getChild('thumbnail', mediaNs);
  if (thumbnail) {
    var url = thumbnail.getAttribute('url');
    if (url) return url.getValue();
  }

  // Try media:content
  var mediaContent = entry.getChild('content', mediaNs);
  if (mediaContent) {
    var url2 = mediaContent.getAttribute('url');
    if (url2) return url2.getValue();
  }

  // Try content HTML
  var content = getChildTextNS(entry, 'content', atomNs);
  var imgMatch = content.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (imgMatch) return imgMatch[1];

  return '';
}

/**
 * Strip HTML tags from a string.
 */
function stripHTML(html) {
  if (!html) return '';
  return html.replace(/<[^>]*>/g, ' ').replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#039;/g, "'")
    .replace(/\s+/g, ' ').trim();
}

/**
 * Parse date string into Date object.
 * Handles RFC 2822 and ISO 8601 formats.
 */
function parseDate(dateString) {
  if (!dateString) return new Date(0);
  try {
    var d = new Date(dateString);
    if (isNaN(d.getTime())) return new Date(0);
    return d;
  } catch (e) {
    return new Date(0);
  }
}

/**
 * Filter articles to only include recent ones (within last 24 hours).
 * @param {Array} articles
 * @returns {Array} Recent articles only
 */
function filterRecentArticles(articles) {
  var oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  return articles.filter(function(article) {
    return article.pubDate.getTime() > oneDayAgo.getTime();
  });
}

/**
 * Get top N articles from combined feed.
 * @param {number} count - Number of articles to return
 * @returns {Array} Top articles
 */
function getTopArticles(count) {
  var allArticles = fetchAllArticles();
  var recentArticles = filterRecentArticles(allArticles);
  return recentArticles.slice(0, count || CONFIG.MAX_POSTS_PER_RUN * 2);
}
