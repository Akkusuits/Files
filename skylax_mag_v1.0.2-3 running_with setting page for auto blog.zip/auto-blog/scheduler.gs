/**
 * Skylax Mag — Scheduler & Pipeline Orchestrator
 *
 * Manages time-based triggers and runs the full auto-blogging pipeline.
 */

// ─── Pipeline Entry Points ───────────────────────────────────

/**
 * MAIN PIPELINE — Run the full auto-blogging flow.
 * This is triggered by the time-based trigger.
 */
function main() {
  Logger.log('=== Skylax Mag Auto-Blog Pipeline Started ===');
  Logger.log('Time: ' + new Date().toISOString());

  try {
    // Step 1: Check rate limit
    if (wasRecentPost(CONFIG.MIN_HOURS_BETWEEN_POSTS)) {
      Logger.log('Rate limited — skipping (min gap: ' + CONFIG.MIN_HOURS_BETWEEN_POSTS + 'h)');
      return;
    }

    // Step 2: Fetch RSS articles
    Logger.log('Fetching RSS feeds...');
    var articles = getTopArticles(CONFIG.MAX_POSTS_PER_RUN * 3);  // Fetch extra for dedup
    Logger.log('Fetched ' + articles.length + ' articles');

    if (articles.length === 0) {
      Logger.log('No articles found — exiting');
      return;
    }

    // Step 3: Filter out already-processed articles
    var newArticles = [];
    for (var i = 0; i < articles.length; i++) {
      if (!isAlreadyProcessed(articles[i].link)) {
        newArticles.push(articles[i]);
      }
      if (newArticles.length >= CONFIG.MAX_POSTS_PER_RUN) break;
    }

    Logger.log('New articles to process: ' + newArticles.length);

    if (newArticles.length === 0) {
      Logger.log('All articles already processed — exiting');
      return;
    }

    // Step 4: Process each article
    var published = 0;
    for (var j = 0; j < newArticles.length; j++) {
      var article = newArticles[j];
      Logger.log('Processing: ' + article.title);

      // Classify labels
      var labels = classifyArticle(article);
      Logger.log('Labels: ' + labels.join(', '));

      // AI Rewrite
      var rewritten = rewriteArticle(article);
      Logger.log('AI Provider: ' + rewritten.provider + ' | Success: ' + rewritten.success);

      // Format for Blogger
      var blogContent = formatForBlogger(rewritten.content, article);

      // Publish
      var publishResult = publishPost(
        rewritten.title,
        blogContent,
        labels,
        article.thumbnail
      );

      // Log result
      logPost({
        source: article.source,
        originalTitle: article.title,
        blogTitle: rewritten.title,
        url: article.link,
        status: publishResult.dryRun ? 'dry-run' : (publishResult.success ? 'published' : 'failed'),
        labels: labels,
        postUrl: publishResult.postUrl || '',
        error: publishResult.error || ''
      });

      if (publishResult.success) {
        published++;
        Logger.log('Published: ' + rewritten.title);
      } else {
        Logger.log('Failed: ' + publishResult.error);
      }
    }

    Logger.log('=== Pipeline Complete: ' + published + '/' + newArticles.length + ' published ===');

  } catch (e) {
    Logger.log('Pipeline error: ' + e.message);
    Logger.log('Stack: ' + e.stack);

    logPost({
      source: 'pipeline',
      originalTitle: 'Pipeline Error',
      blogTitle: '',
      url: '',
      status: 'failed',
      labels: [],
      postUrl: '',
      error: e.message
    });
  }
}

/**
 * MANUAL RUN — Trigger the pipeline manually from the editor.
 * Same as main() but also logs that it was a manual trigger.
 */
function runNow() {
  Logger.log('=== MANUAL TRIGGER ===');
  main();
}

// ─── Schedule Management ─────────────────────────────────────

/**
 * Setup the time-based trigger based on CONFIG.ACTIVE_SCHEDULE.
 * Deletes existing triggers and creates a new one.
 */
function setupSchedule() {
  var hours = getIntervalHours();
  Logger.log('Setting up schedule: every ' + hours + ' hours');

  // Delete existing time-based triggers
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      ScriptApp.deleteTrigger(triggers[i]);
      Logger.log('Deleted old trigger');
    }
  }

  // Create new trigger
  ScriptApp.newTrigger('main')
    .timeBased()
    .everyHours(hours)
    .create();

  Logger.log('New trigger created: every ' + hours + ' hours');
  Logger.log('Next run will be approximately: ' + new Date(Date.now() + hours * 60 * 60 * 1000).toLocaleString());
}

/**
 * Remove all scheduled triggers.
 */
function removeSchedule() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      ScriptApp.deleteTrigger(triggers[i]);
      Logger.log('Removed trigger');
    }
  }
  Logger.log('All schedule triggers removed');
}

/**
 * Get info about current triggers.
 */
function getScheduleInfo() {
  var triggers = ScriptApp.getProjectTriggers();
  var info = [];

  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      info.push({
        handler: triggers[i].getHandlerFunction(),
        type: triggers[i].getEventType(),
        nextRun: triggers[i].getNextExecutionTimestamp(),
        intervalHours: getIntervalHours()
      });
    }
  }

  if (info.length === 0) {
    Logger.log('No active schedule triggers');
  } else {
    for (var j = 0; j < info.length; j++) {
      Logger.log('Trigger: ' + info[j].handler + ' | Next: ' + info[j].nextRun + ' | Interval: ' + info[j].intervalHours + 'h');
    }
  }

  return info;
}

// ─── Setup Functions ─────────────────────────────────────────

/**
 * First-time setup wizard.
 * Run this once after configuring config.gs.
 */
function setup() {
  Logger.log('=== Skylax Mag Auto-Blog Setup ===');

  // 1. Initialize log sheet
  Logger.log('Step 1: Initializing log sheet...');
  initLogSheet();

  // 2. Setup schedule
  Logger.log('Step 2: Setting up schedule...');
  setupSchedule();

  // 3. Verify config
  Logger.log('Step 3: Verifying configuration...');
  var issues = [];

  if (CONFIG.BLOG_ID === 'YOUR_BLOG_ID') {
    issues.push('BLOG_ID not configured — edit config.gs');
  }
  if (CONFIG.LOG_SHEET_ID === 'YOUR_GOOGLE_SHEET_ID') {
    issues.push('LOG_SHEET_ID not configured — edit config.gs');
  }
  if (!CONFIG.GROQ_API_KEY || CONFIG.GROQ_API_KEY === 'gsk_...') {
    issues.push('GROQ_API_KEY not configured — get free key at console.groq.com');
  }
  if (!CONFIG.GEMINI_API_KEY) {
    Logger.log('Warning: GEMINI_API_KEY not set (fallback will be unavailable)');
  }

  if (issues.length > 0) {
    Logger.log('=== Setup Incomplete — Issues Found ===');
    for (var i = 0; i < issues.length; i++) {
      Logger.log('  ✗ ' + issues[i]);
    }
    Logger.log('Edit config.gs and run setup() again');
  } else {
    Logger.log('=== Setup Complete ✓ ===');
    Logger.log('Blog: ' + CONFIG.BLOG_URL);
    Logger.log('Schedule: ' + CONFIG.ACTIVE_SCHEDULE + ' (' + getIntervalHours() + 'h)');
    Logger.log('Max posts per run: ' + CONFIG.MAX_POSTS_PER_RUN);
    Logger.log('Dry run: ' + CONFIG.DRY_RUN);
    Logger.log('');
    Logger.log('Next steps:');
    Logger.log('  1. Run testPipeline() to do a dry run');
    Logger.log('  2. Set DRY_RUN to false in config.gs');
    Logger.log('  3. The schedule will auto-publish articles');
  }
}

/**
 * Test the pipeline without publishing.
 * Temporarily enables dry run mode.
 */
function testPipeline() {
  var originalDryRun = CONFIG.DRY_RUN;
  CONFIG.DRY_RUN = true;

  Logger.log('=== TEST RUN (Dry Run Mode) ===');
  main();

  CONFIG.DRY_RUN = originalDryRun;
  Logger.log('=== Test Complete ===');
}

// ─── Dashboard Entry Point ───────────────────────────────────

/**
 * Serve the dashboard HTML page.
 * Access at: https://script.google.com/macros/s/{SCRIPT_ID}/exec
 */
function doGet(e) {
  // Route OAuth callbacks to blogger_publisher.gs
  if (e && e.parameter && e.parameter.code) {
    return doGetOAuth(e);
  }
  // Serve dashboard
  return HtmlService.createHtmlOutputFromFile('dashboard')
    .setTitle('Skylax Mag — Auto-Blog Dashboard')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * API endpoint for dashboard to get stats.
 */
function getDashboardData() {
  return {
    stats: getLogStats(),
    recentLogs: getRecentLogs(15),
    schedule: {
      active: CONFIG.ACTIVE_SCHEDULE,
      intervalHours: getIntervalHours(),
      customHours: CONFIG.SCHEDULE_CUSTOM_HOURS,
      maxPerRun: CONFIG.MAX_POSTS_PER_RUN,
      minGapHours: CONFIG.MIN_HOURS_BETWEEN_POSTS,
      dryRun: CONFIG.DRY_RUN
    },
    sources: CONFIG.SOURCES.map(function(s) {
      return { name: s.name, enabled: s.enabled, url: s.url };
    }),
    labels: Object.keys(CONFIG.LABELS).map(function(key) {
      return { name: key, enabled: CONFIG.LABELS[key].enabled };
    })
  };
}
