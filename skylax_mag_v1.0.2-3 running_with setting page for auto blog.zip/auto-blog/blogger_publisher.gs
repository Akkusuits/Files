/**
 * Skylax Mag — Blogger Publisher (Self-Contained)
 *
 * Publishes posts to Blogger using manual OAuth2 flow.
 * NO external libraries required — everything is built-in.
 *
 * SETUP:
 * 1. Create OAuth credentials in Google Cloud Console (see SETUP_GUIDE.md Step 3.4)
 * 2. Update OAUTH_CONFIG below with your Client ID and Client Secret
 * 3. Update CONFIG.BLOG_ID with your Blogger Blog ID
 * 4. Run setupOAuth() to authorize
 * 5. Run testPipeline() to verify
 */

// ─── OAuth2 Config ─────────────────────────────────────────

var OAUTH_CONFIG = {
  clientId: '868326236939-l87pog2tirr6bi5mc5vr9t2gsc1akaor.apps.googleusercontent.com',
  clientSecret: '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',
  scope: 'https://www.googleapis.com/auth/blogger',
  authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
  tokenUrl: 'https://oauth2.googleapis.com/token'
};

// ─── OAuth2 Helper Functions ───────────────────────────────

function getOAuthService() {
  var props = PropertiesService.getUserProperties();
  return {
    getAccessToken: function() { return props.getProperty('BLOGGER_ACCESS_TOKEN') || ''; },
    getRefreshToken: function() { return props.getProperty('BLOGGER_REFRESH_TOKEN') || ''; },
    getExpirationTime: function() { return parseInt(props.getProperty('BLOGGER_TOKEN_EXPIRY') || '0'); },
    setTokens: function(access, refresh, expiresAt) {
      props.setProperty('BLOGGER_ACCESS_TOKEN', access);
      if (refresh) props.setProperty('BLOGGER_REFRESH_TOKEN', refresh);
      if (expiresAt) props.setProperty('BLOGGER_TOKEN_EXPIRY', expiresAt.toString());
    },
    hasAccess: function() {
      var token = this.getAccessToken();
      var expiry = this.getExpirationTime();
      return token !== '' && Date.now() < expiry;
    },
    clear: function() {
      props.deleteProperty('BLOGGER_ACCESS_TOKEN');
      props.deleteProperty('BLOGGER_REFRESH_TOKEN');
      props.deleteProperty('BLOGGER_TOKEN_EXPIRY');
    }
  };
}

function refreshAccessToken() {
  var service = getOAuthService();
  var refreshToken = service.getRefreshToken();

  if (!refreshToken) {
    Logger.log('No refresh token — run setupOAuth() first');
    return null;
  }

  var payload = 'client_id=' + encodeURIComponent(OAUTH_CONFIG.clientId) +
    '&client_secret=' + encodeURIComponent(OAUTH_CONFIG.clientSecret) +
    '&refresh_token=' + encodeURIComponent(refreshToken) +
    '&grant_type=refresh_token';

  var response = UrlFetchApp.fetch(OAUTH_CONFIG.tokenUrl, {
    method: 'post',
    contentType: 'application/x-www-form-urlencoded',
    payload: payload,
    muteHttpExceptions: true
  });

  var code = response.getResponseCode();
  var result = JSON.parse(response.getContentText());

  if (code === 200 && result.access_token) {
    var expiresAt = Date.now() + ((result.expires_in || 3600) * 1000) - 60000;
    service.setTokens(result.access_token, null, expiresAt);
    Logger.log('Access token refreshed successfully');
    return result.access_token;
  }

  Logger.log('Token refresh failed: ' + (result.error_description || 'HTTP ' + code));
  return null;
}

function getAccessToken() {
  var service = getOAuthService();

  // Try existing token first
  if (service.hasAccess()) {
    return service.getAccessToken();
  }

  // Try refreshing
  var token = refreshAccessToken();
  if (token) return token;

  return null;
}

// ─── OAuth2 Authorization Flow ─────────────────────────────

/**
 * Run this FIRST to authorize the script.
 * Opens a browser window for Google OAuth consent.
 */
function setupOAuth() {
  var service = getOAuthService();

  if (service.hasAccess()) {
    Logger.log('Already authorized!');
    var blog = getBlogInfo();
    if (blog) {
      Logger.log('Blog: ' + blog.name);
      Logger.log('URL: ' + blog.url);
    }
    return;
  }

  // Build authorization URL
  var redirectUri = ScriptApp.getService().getUrl();
  var authUrl = OAUTH_CONFIG.authUrl +
    '?client_id=' + encodeURIComponent(OAUTH_CONFIG.clientId) +
    '&redirect_uri=' + encodeURIComponent(redirectUri) +
    '&response_type=code' +
    '&scope=' + encodeURIComponent(OAUTH_CONFIG.scope) +
    '&access_type=offline' +
    '&prompt=consent';

  Logger.log('=== Authorization Required ===');
  Logger.log('Click the link below to authorize:');
  Logger.log(authUrl);
  Logger.log('');

  // Also try to open it automatically
  try {
    var html = '<script>window.open("' + authUrl + '");</script><p>Authorization window opened. If it didn\'t open, <a href="' + authUrl + '" target="_blank">click here</a>.</p>';
    var ui = HtmlService.createHtmlOutput(html).setWidth(500).setHeight(200);
    SpreadsheetApp.getUi().showModalDialog(ui, 'Authorize Skylax Mag');
  } catch (e) {
    Logger.log('Could not open browser — copy the URL above and open it manually');
  }
}

/**
 * OAuth2 callback handler — called from the unified doGet in scheduler.gs
 * when the ?code= parameter is present.
 */
function doGetOAuth(e) {
  var code = e.parameter.code;

  if (!code) {
    return HtmlService.createHtmlOutput('<h2>Authorization failed</h2><p>No authorization code received.</p>');
  }

  // Exchange code for tokens
  var payload = 'client_id=' + encodeURIComponent(OAUTH_CONFIG.clientId) +
    '&client_secret=' + encodeURIComponent(OAUTH_CONFIG.clientSecret) +
    '&code=' + encodeURIComponent(code) +
    '&grant_type=authorization_code' +
    '&redirect_uri=' + encodeURIComponent(ScriptApp.getService().getUrl());

  var response = UrlFetchApp.fetch(OAUTH_CONFIG.tokenUrl, {
    method: 'post',
    contentType: 'application/x-www-form-urlencoded',
    payload: payload,
    muteHttpExceptions: true
  });

  var result = JSON.parse(response.getContentText());

  if (result.access_token) {
    var service = getOAuthService();
    var expiresAt = Date.now() + ((result.expires_in || 3600) * 1000) - 60000;
    service.setTokens(result.access_token, result.refresh_token, expiresAt);
    Logger.log('Authorization successful!');

    // Verify blog access
    var blog = getBlogInfo();
    var blogName = blog ? blog.name : 'Unknown';
    var blogUrl = blog ? blog.url : '';

    return HtmlService.createHtmlOutput(
      '<h2>✅ Authorization Successful!</h2>' +
      '<p><strong>Blog:</strong> ' + blogName + '</p>' +
      '<p><strong>URL:</strong> ' + blogUrl + '</p>' +
      '<p>You can close this tab and return to Apps Script.</p>' +
      '<p>Run <code>testPipeline()</code> to test the auto-blogging system.</p>'
    );
  } else {
    Logger.log('Token exchange failed: ' + (result.error_description || JSON.stringify(result)));
    return HtmlService.createHtmlOutput(
      '<h2>❌ Authorization Failed</h2>' +
      '<p>Error: ' + (result.error_description || 'Unknown error') + '</p>' +
      '<p>Check your Client ID and Client Secret in config.</p>'
    );
  }
}

/**
 * Disconnect / reset OAuth (for testing).
 */
function disconnectOAuth() {
  var service = getOAuthService();
  service.clear();
  Logger.log('OAuth disconnected. Run setupOAuth() to re-authorize.');
}

// ─── Blogger API Functions ─────────────────────────────────

/**
 * Get blog info.
 */
function getBlogInfo() {
  var token = getAccessToken();
  if (!token) return null;

  var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID;
  var response = UrlFetchApp.fetch(url, {
    headers: { 'Authorization': 'Bearer ' + token },
    muteHttpExceptions: true
  });

  if (response.getResponseCode() === 200) {
    return JSON.parse(response.getContentText());
  }
  return null;
}

/**
 * Publish a post to Blogger.
 *
 * @param {string} title - Post title
 * @param {string} htmlContent - HTML body content
 * @param {Array} labels - Array of label strings
 * @param {string} imageUrl - Featured image URL (optional)
 * @returns {Object} { success, postUrl, postId, error }
 */
function publishPost(title, htmlContent, labels, imageUrl) {
  // Dry run check
  if (CONFIG.DRY_RUN) {
    Logger.log('[DRY RUN] Would publish: ' + title);
    Logger.log('[DRY RUN] Labels: ' + labels.join(', '));
    return { success: true, postUrl: '(dry run)', postId: '(dry run)', error: null, dryRun: true };
  }

  var token = getAccessToken();
  if (!token) {
    Logger.log('Not authorized — run setupOAuth() first');
    return { success: false, postUrl: null, postId: null, error: 'Not authorized. Run setupOAuth() first.', dryRun: false };
  }

  try {
    // Build the post body with featured image
    var body = '';
    if (imageUrl) {
      body += '<div class="post-thumbnail" style="margin-bottom:20px;">\n';
      body += '  <img src="' + imageUrl + '" alt="' + (title || '') + '" style="max-width:100%;height:auto;border-radius:8px;"/>\n';
      body += '</div>\n\n';
    }
    body += htmlContent;

    var payload = JSON.stringify({
      kind: 'blogger#post',
      blog: { id: CONFIG.BLOG_ID },
      title: title,
      content: body,
      labels: labels
    });

    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/posts';
    var response = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: payload,
      headers: { 'Authorization': 'Bearer ' + token },
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var result = JSON.parse(response.getContentText());

    if (code === 200) {
      Logger.log('Published: ' + title + ' (ID: ' + result.id + ')');
      return { success: true, postUrl: result.url, postId: result.id, error: null, dryRun: false };
    }

    var errorMsg = result.error ? result.error.message : 'HTTP ' + code;
    Logger.log('Publish error: ' + errorMsg);
    return { success: false, postUrl: null, postId: null, error: errorMsg, dryRun: false };
  } catch (e) {
    Logger.log('Publish error: ' + e.message);
    return { success: false, postUrl: null, postId: null, error: e.message, dryRun: false };
  }
}

/**
 * Get existing blog posts (for dedup checking).
 * @param {number} count - Number of recent posts to fetch
 */
function getRecentPosts(count) {
  var token = getAccessToken();
  if (!token) return [];

  try {
    var url = 'https://www.googleapis.com/blogger/v3/blogs/' + CONFIG.BLOG_ID + '/posts?maxResults=' + (count || 20) + '&orderBy=PUBLISHED&status=live';
    var response = UrlFetchApp.fetch(url, {
      headers: { 'Authorization': 'Bearer ' + token },
      muteHttpExceptions: true
    });

    if (response.getResponseCode() !== 200) return [];

    var result = JSON.parse(response.getContentText());
    if (!result.items) return [];

    return result.items.map(function(post) {
      return {
        id: post.id,
        title: post.title,
        url: post.url,
        published: post.published,
        labels: post.labels || []
      };
    });
  } catch (e) {
    Logger.log('Error fetching posts: ' + e.message);
    return [];
  }
}
