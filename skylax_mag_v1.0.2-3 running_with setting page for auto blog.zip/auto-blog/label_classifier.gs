/**
 * Skylax Mag — Label Classifier
 *
 * Automatically assigns FIFA-relevant labels to articles based on content analysis.
 * Uses keyword matching — no API calls needed.
 */

/**
 * Classify an article and return matching labels.
 * Returns up to 3 most relevant labels.
 *
 * @param {Object} article - { title, description, rawContent }
 * @returns {Array} Array of label strings
 */
function classifyArticle(article) {
  var text = ((article.title || '') + ' ' + (article.description || '') + ' ' + (article.rawContent || '')).toLowerCase();
  var enabledLabels = getEnabledLabels();
  var scores = {};

  // Score each enabled label based on keyword matches
  for (var label in enabledLabels) {
    var keywords = enabledLabels[label].keywords;
    var score = 0;

    for (var i = 0; i < keywords.length; i++) {
      var keyword = keywords[i].toLowerCase();
      // Count occurrences of keyword in text
      var regex = new RegExp('\\b' + escapeRegex(keyword) + '\\b', 'gi');
      var matches = text.match(regex);
      if (matches) {
        score += matches.length;
      }
    }

    if (score > 0) {
      scores[label] = score;
    }
  }

  // Sort by score descending
  var sortedLabels = Object.keys(scores).sort(function(a, b) {
    return scores[b] - scores[a];
  });

  // Return top 3 (or fewer)
  var result = sortedLabels.slice(0, 3);

  // Ensure at least one label — default to 'news'
  if (result.length === 0) {
    if (enabledLabels['news']) {
      result = ['news'];
    } else {
      // Find first enabled label
      for (var fallbackLabel in enabledLabels) {
        result = [fallbackLabel];
        break;
      }
    }
  }

  return result;
}

/**
 * Escape special regex characters in a string.
 */
function escapeRegex(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Get a human-readable description of the classification.
 * Useful for logging and debugging.
 *
 * @param {Object} article
 * @param {Array} labels - Assigned labels
 * @returns {string} Description string
 */
function describeClassification(article, labels) {
  if (!labels || labels.length === 0) return 'Unclassified';

  var desc = labels.map(function(label) {
    return label.replace(/-/g, ' ');
  });

  if (desc.length === 1) return desc[0];
  if (desc.length === 2) return desc[0] + ' & ' + desc[1];
  return desc[0] + ', ' + desc[1] + ' & ' + desc[2];
}

/**
 * Test the classifier with sample content.
 * Run this function from Apps Script editor to test.
 */
function testClassifier() {
  var testArticles = [
    {
      title: 'Mbappe signs new contract extension with Real Madrid',
      description: 'Kylian Mbappe has agreed a new long-term deal with the Spanish giants, securing his future at the Bernabeu until 2030.',
      rawContent: ''
    },
    {
      title: 'World Cup 2026: Host cities announce final preparations',
      description: 'With the FIFA World Cup 2026 approaching, host cities across USA, Mexico and Canada are completing their stadium upgrades.',
      rawContent: ''
    },
    {
      title: 'Manchester United 2-1 Liverpool: Match report',
      description: 'A dramatic late winner saw Manchester United claim all three points in a thrilling Premier League encounter at Old Trafford.',
      rawContent: ''
    },
    {
      title: 'Champions League draw: Quarter-final fixtures confirmed',
      description: 'The draw for the Champions League quarter-finals has produced some fascinating ties, with Real Madrid facing Manchester City.',
      rawContent: ''
    },
    {
      title: 'Tactical analysis: How Arsenal\'s pressing system dismantled Bayern',
      description: 'Arsenal\'s high press and counter-attacking formation proved too much for Bayern Munich in their Champions League meeting.',
      rawContent: ''
    }
  ];

  for (var i = 0; i < testArticles.length; i++) {
    var labels = classifyArticle(testArticles[i]);
    Logger.log('Article: ' + testArticles[i].title);
    Logger.log('Labels: ' + labels.join(', '));
    Logger.log('Description: ' + describeClassification(testArticles[i], labels));
    Logger.log('---');
  }
}
