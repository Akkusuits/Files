/**
 * Skylax Mag — Server-Side Ad Revenue Analytics
 *
 * Receives ad impression/click data from the client-side smart-ads.js
 * and logs it to a Google Sheet for analysis and reporting.
 */

// ─── Constants ─────────────────────────────────────────────

var AD_LOG_SHEET_NAME = 'Ad Revenue';
var AD_LOG_HEADERS = [
  'Timestamp', 'Page URL', 'Slot ID', 'Device',
  'Impression', 'Click', 'Viewable', 'Network',
  'CTR', 'Session ID'
];

// ─── Sheet Initialization ─────────────────────────────────

/**
 * Initialize the Ad Revenue log sheet with headers.
 * Run this once from the Apps Script editor.
 */
function initAdLogSheet() {
  var ss = SpreadsheetApp.openById(CONFIG.LOG_SHEET_ID);
  var sheet = ss.getSheetByName(AD_LOG_SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(AD_LOG_SHEET_NAME);
  }

  // Check if headers exist
  var existingHeaders = sheet.getRange(1, 1, 1, AD_LOG_HEADERS.length).getValues()[0];
  if (existingHeaders[0] === 'Timestamp') {
    Logger.log('Ad Revenue sheet already initialized');
    return sheet;
  }

  // Set headers
  sheet.getRange(1, 1, 1, AD_LOG_HEADERS.length).setValues([AD_LOG_HEADERS]);

  // Format header row
  var headerRange = sheet.getRange(1, 1, 1, AD_LOG_HEADERS.length);
  headerRange.setFontWeight('bold');
  headerRange.setBackground('#00529F');
  headerRange.setFontColor('#ffffff');

  // Set column widths
  sheet.setColumnWidth(1, 160);  // Timestamp
  sheet.setColumnWidth(2, 250);  // Page URL
  sheet.setColumnWidth(3, 120);  // Slot ID
  sheet.setColumnWidth(4, 80);   // Device
  sheet.setColumnWidth(5, 80);   // Impression
  sheet.setColumnWidth(6, 60);   // Click
  sheet.setColumnWidth(7, 80);   // Viewable
  sheet.setColumnWidth(8, 80);   // Network
  sheet.setColumnWidth(9, 60);   // CTR
  sheet.setColumnWidth(10, 120); // Session ID

  Logger.log('Ad Revenue sheet initialized successfully');
  return sheet;
}

// ─── Data Reception ───────────────────────────────────────

/**
 * Receive batched ad events from the client.
 * Called via google.script.run from smart-ads.js.
 *
 * @param {Array} events - Array of event objects
 *   { timestamp, url, slotId, device, impression, click, viewable, network, sessionId }
 * @returns {Object} { success, count }
 */
function receiveAdEvents(events) {
  try {
    var sheet = getAdLogSheet();
    if (!sheet) {
      return { success: false, count: 0, error: 'Sheet not found' };
    }

    var rows = [];
    for (var i = 0; i < events.length; i++) {
      var e = events[i];
      var ctr = e.impression && e.click ? (e.click / e.impression * 100).toFixed(2) : '0';

      rows.push([
        new Date(e.timestamp),
        e.url || '',
        e.slotId || '',
        e.device || 'unknown',
        e.impression || 0,
        e.click || 0,
        e.viewable || 0,
        e.network || 'adsense',
        ctr,
        e.sessionId || ''
      ]);
    }

    if (rows.length > 0) {
      sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, AD_LOG_HEADERS.length).setValues(rows);
    }

    Logger.log('Received ' + rows.length + ' ad events');
    return { success: true, count: rows.length };
  } catch (e) {
    Logger.log('Error receiving ad events: ' + e.message);
    return { success: false, count: 0, error: e.message };
  }
}

/**
 * Get the Ad Revenue log sheet.
 * @returns {GoogleAppsScript.Sheets.Sheet}
 */
function getAdLogSheet() {
  try {
    var ss = SpreadsheetApp.openById(CONFIG.LOG_SHEET_ID);
    var sheet = ss.getSheetByName(AD_LOG_SHEET_NAME);
    if (!sheet) {
      sheet = initAdLogSheet();
    }
    return sheet;
  } catch (e) {
    Logger.log('Error accessing Ad Revenue sheet: ' + e.message);
    return null;
  }
}

// ─── Analytics Queries ─────────────────────────────────────

/**
 * Get ad performance summary for a date range.
 *
 * @param {Date} startDate
 * @param {Date} endDate
 * @returns {Object} Aggregated stats
 */
function getAdPerformance(startDate, endDate) {
  var sheet = getAdLogSheet();
  if (!sheet) return { error: 'Sheet not found' };

  var lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { totalImpressions: 0, totalClicks: 0, slots: {} };

  var data = sheet.getRange(2, 1, lastRow - 1, AD_LOG_HEADERS.length).getValues();

  var stats = {
    totalImpressions: 0,
    totalClicks: 0,
    totalViewable: 0,
    slots: {},
    byDevice: { mobile: { impressions: 0, clicks: 0 }, tablet: { impressions: 0, clicks: 0 }, desktop: { impressions: 0, clicks: 0 } },
    byNetwork: { adsense: { impressions: 0, clicks: 0 }, monetag: { impressions: 0, clicks: 0 }, adsterra: { impressions: 0, clicks: 0 } }
  };

  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    var timestamp = new Date(row[0]);
    var slotId = row[2];
    var device = row[3];
    var impression = parseInt(row[4]) || 0;
    var click = parseInt(row[5]) || 0;
    var viewable = parseInt(row[6]) || 0;
    var network = row[7];

    // Filter by date range
    if (startDate && timestamp < startDate) continue;
    if (endDate && timestamp > endDate) continue;

    // Aggregate
    stats.totalImpressions += impression;
    stats.totalClicks += click;
    stats.totalViewable += viewable;

    // By slot
    if (!stats.slots[slotId]) stats.slots[slotId] = { impressions: 0, clicks: 0, viewable: 0 };
    stats.slots[slotId].impressions += impression;
    stats.slots[slotId].clicks += click;
    stats.slots[slotId].viewable += viewable;

    // By device
    if (stats.byDevice[device]) {
      stats.byDevice[device].impressions += impression;
      stats.byDevice[device].clicks += click;
    }

    // By network
    if (stats.byNetwork[network]) {
      stats.byNetwork[network].impressions += impression;
      stats.byNetwork[network].clicks += click;
    }
  }

  // Calculate CTR per slot
  for (var slot in stats.slots) {
    stats.slots[slot].ctr = stats.slots[slot].impressions > 0
      ? (stats.slots[slot].clicks / stats.slots[slot].impressions * 100).toFixed(2)
      : 0;
    stats.slots[slot].viewability = stats.slots[slot].impressions > 0
      ? (stats.slots[slot].viewable / stats.slots[slot].impressions * 100).toFixed(2)
      : 0;
  }

  stats.ctr = stats.totalImpressions > 0
    ? (stats.totalClicks / stats.totalImpressions * 100).toFixed(2)
    : 0;
  stats.viewability = stats.totalImpressions > 0
    ? (stats.totalViewable / stats.totalImpressions * 100).toFixed(2)
    : 0;

  return stats;
}

/**
 * Get today's ad performance.
 */
function getTodayStats() {
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  return getAdPerformance(today, new Date());
}

/**
 * Get this week's ad performance.
 */
function getWeekStats() {
  var now = new Date();
  var weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  return getAdPerformance(weekAgo, now);
}

/**
 * Get this month's ad performance.
 */
function getMonthStats() {
  var now = new Date();
  var monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  return getAdPerformance(monthStart, now);
}

/**
 * Get top performing ad slots.
 * @param {number} limit - Number of top slots to return
 */
function getTopSlots(limit) {
  var stats = getWeekStats();
  var slots = [];

  for (var slotId in stats.slots) {
    slots.push({
      slotId: slotId,
      impressions: stats.slots[slotId].impressions,
      clicks: stats.slots[slotId].clicks,
      ctr: stats.slots[slotId].ctr,
      viewability: stats.slots[slotId].viewability
    });
  }

  slots.sort(function(a, b) { return b.impressions - a.impressions; });
  return slots.slice(0, limit || 5);
}

// ─── Dashboard Integration ─────────────────────────────────

/**
 * Get all ad analytics data for the dashboard.
 */
function getAdAnalyticsData() {
  return {
    today: getTodayStats(),
    week: getWeekStats(),
    month: getMonthStats(),
    topSlots: getTopSlots(5)
  };
}

// ─── Daily Aggregation Job ─────────────────────────────────

/**
 * Aggregate daily ad data.
 * Run this via time-based trigger (once per day).
 */
function aggregateDailyAdData() {
  Logger.log('Running daily ad data aggregation...');

  var stats = getTodayStats();
  var dateStr = new Date().toISOString().split('T')[0];

  // Store aggregated data
  var props = PropertiesService.getScriptProperties();
  var key = 'ad_daily_' + dateStr;
  props.setProperty(key, JSON.stringify(stats));

  Logger.log('Daily aggregation complete: ' + stats.totalImpressions + ' impressions, ' + stats.totalClicks + ' clicks');
}

/**
 * Get historical daily data for charts.
 * @param {number} days - Number of days to look back
 */
function getDailyHistory(days) {
  var props = PropertiesService.getScriptProperties();
  var history = [];

  for (var i = 0; i < (days || 30); i++) {
    var date = new Date();
    date.setDate(date.getDate() - i);
    var dateStr = date.toISOString().split('T')[0];
    var key = 'ad_daily_' + dateStr;
    var data = props.getProperty(key);

    if (data) {
      var stats = JSON.parse(data);
      history.push({
        date: dateStr,
        impressions: stats.totalImpressions || 0,
        clicks: stats.totalClicks || 0,
        ctr: stats.ctr || 0
      });
    }
  }

  return history.reverse();
}
