/**
 * Skylax Mag — AI Content Rewriter
 *
 * Rewrites football news articles using Groq (primary) or Gemini (fallback).
 * Produces unique, engaging content for the Skylax Mag blog.
 */

/**
 * Rewrite an article using AI.
 * Tries Groq first (if provider is 'groq' or 'auto'), falls back to Gemini.
 *
 * @param {Object} article - { title, description, rawContent }
 * @returns {Object} { title, content, success, provider, error }
 */
function rewriteArticle(article) {
  var prompt = CONFIG.AI_PROMPT
    .replace('{title}', article.title)
    .replace('{content}', article.description || article.rawContent || '');

  var provider = CONFIG.AI_PROVIDER;

  // Try primary provider
  if (provider === 'groq' || provider === 'auto') {
    var result = callGroq(prompt);
    if (result.success) {
      return {
        title: generateBlogTitle(article.title),
        content: result.content,
        success: true,
        provider: 'groq',
        error: null
      };
    }
    Logger.log('Groq failed: ' + result.error + ' — trying Gemini fallback');
  }

  // Fallback to Gemini
  if (provider === 'gemini' || provider === 'auto') {
    var result2 = callGemini(prompt);
    if (result2.success) {
      return {
        title: generateBlogTitle(article.title),
        content: result2.content,
        success: true,
        provider: 'gemini',
        error: null
      };
    }
    Logger.log('Gemini also failed: ' + result2.error);
    return {
      title: generateBlogTitle(article.title),
      content: formatFallbackContent(article),
      success: false,
      provider: 'fallback',
      error: 'Both AI providers failed: ' + result2.error
    };
  }

  return {
    title: generateBlogTitle(article.title),
    content: formatFallbackContent(article),
    success: false,
    provider: 'none',
    error: 'No AI provider configured'
  };
}

/**
 * Call Groq API for content generation.
 * @param {string} prompt - The full prompt to send
 * @returns {Object} { success, content, error }
 */
function callGroq(prompt) {
  if (!CONFIG.GROQ_API_KEY || CONFIG.GROQ_API_KEY === 'gsk_...') {
    return { success: false, content: '', error: 'Groq API key not configured' };
  }

  var payload = JSON.stringify({
    model: CONFIG.GROQ_MODEL,
    messages: [
      {
        role: 'system',
        content: 'You are an expert football journalist. Write engaging, original content about football/soccer. Always use HTML formatting for blog posts.'
      },
      {
        role: 'user',
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: 1000
  });

  try {
    var response = UrlFetchApp.fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'post',
      contentType: 'application/json',
      headers: {
        'Authorization': 'Bearer ' + CONFIG.GROQ_API_KEY
      },
      payload: payload,
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var body = JSON.parse(response.getContentText());

    if (code === 200 && body.choices && body.choices[0]) {
      return {
        success: true,
        content: body.choices[0].message.content.trim(),
        error: null
      };
    }

    var errorMsg = body.error ? body.error.message : 'HTTP ' + code;
    return { success: false, content: '', error: errorMsg };
  } catch (e) {
    return { success: false, content: '', error: e.message };
  }
}

/**
 * Call Google Gemini API for content generation.
 * @param {string} prompt - The full prompt to send
 * @returns {Object} { success, content, error }
 */
function callGemini(prompt) {
  if (!CONFIG.GEMINI_API_KEY) {
    return { success: false, content: '', error: 'Gemini API key not configured' };
  }

  var payload = JSON.stringify({
    contents: [{
      parts: [{
        text: prompt
      }]
    }],
    generationConfig: {
      temperature: 0.7,
      maxOutputTokens: 1000
    }
  });

  try {
    var url = 'https://generativelanguage.googleapis.com/v1beta/models/' +
              CONFIG.GEMINI_MODEL + ':generateContent?key=' + CONFIG.GEMINI_API_KEY;

    var response = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: payload,
      muteHttpExceptions: true
    });

    var code = response.getResponseCode();
    var body = JSON.parse(response.getContentText());

    if (code === 200 && body.candidates && body.candidates[0]) {
      var text = body.candidates[0].content.parts[0].text;
      return {
        success: true,
        content: text.trim(),
        error: null
      };
    }

    var errorMsg = body.error ? body.error.message : 'HTTP ' + code;
    return { success: false, content: '', error: errorMsg };
  } catch (e) {
    return { success: false, content: '', error: e.message };
  }
}

/**
 * Generate an SEO-friendly blog title from the original.
 * @param {string} originalTitle
 * @returns {string} Blog-optimized title
 */
function generateBlogTitle(originalTitle) {
  if (!originalTitle) return 'Football Update';

  // Clean up the title
  var title = originalTitle
    .replace(/\s*[\|:\-–—]\s*(BBC|Guardian|Sky|ESPN|FOX).*$/i, '')  // Remove source branding
    .replace(/\s*-\s*football.*$/i, '')                               // Remove "football" suffix
    .trim();

  // Ensure reasonable length
  if (title.length > 80) {
    title = title.substring(0, 77) + '...';
  }

  return title;
}

/**
 * Fallback content when AI providers are unavailable.
 * Wraps the original content in Blogger-compatible HTML.
 * @param {Object} article
 * @returns {string} HTML content
 */
function formatFallbackContent(article) {
  var html = '';

  if (article.thumbnail) {
    html += '<div class="post-thumbnail"><img src="' + article.thumbnail + '" alt="' + (article.title || '') + '"/></div>\n';
  }

  html += '<p><em>Originally reported by ' + (article.source || 'Football News') + '</em></p>\n\n';

  // Use raw content if available, otherwise description
  var content = article.rawContent || article.description || '';
  if (content) {
    // Clean up and wrap in paragraphs
    var paragraphs = content.split(/\n\n+/);
    for (var i = 0; i < paragraphs.length; i++) {
      var p = paragraphs[i].replace(/<[^>]*>/g, '').trim();
      if (p) {
        html += '<p>' + p + '</p>\n';
      }
    }
  }

  html += '\n<p><em>Stay tuned for more updates on Skylax Mag.</em></p>';

  return html;
}

/**
 * Format AI-generated content for Blogger.
 * Wraps in proper HTML structure.
 * @param {string} aiContent - Raw AI output
 * @param {Object} article - Original article (for thumbnail)
 * @returns {string} Blogger-ready HTML
 */
function formatForBlogger(aiContent, article) {
  var html = '';

  // Add featured image if available
  if (article && article.thumbnail) {
    html += '<div class="post-thumbnail">\n';
    html += '  <img src="' + article.thumbnail + '" alt="' + (article.title || '') + '"/>\n';
    html += '</div>\n\n';
  }

  // Add the AI-generated content
  html += aiContent;

  // Add source attribution
  html += '\n\n<hr/>\n';
  html += '<p><em>Source: ' + (article.source || 'Football News');
  if (article.link) {
    html += ' | <a href="' + article.link + '" target="_blank" rel="nofollow">Original Article</a>';
  }
  html += '</em></p>';

  return html;
}
