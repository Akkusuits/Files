# Skylax Mag — Complete Setup Guide

Everything you need to deploy the blog, auto-blogging, and smart ads system.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Deploy Blogger Template](#2-deploy-blogger-template)
3. [Setup Google Apps Script (Auto-Blog)](#3-setup-google-apps-script)
4. [Setup Smart Ad Management](#4-setup-smart-ad-management)
5. [Configure Admin Dashboard](#5-configure-admin-dashboard)
6. [Create Blog Pages](#6-create-blog-pages)
7. [First Post & Testing](#7-first-post--testing)
8. [Go Live Checklist](#8-go-live-checklist)

---

## 1. Prerequisites

Before you start, you need these free accounts:

| Service | What For | URL |
|---------|----------|-----|
| Google Account | Blogger, Apps Script, Sheets | accounts.google.com |
| Blogger | Host your blog | blogger.com |
| Groq | Free AI API key | console.groq.com |
| Google Cloud Console | Blogger API (optional) | console.cloud.google.com |

### Step 1.1: Create Your Blog

1. Go to **blogger.com**
2. Click **New Blog**
3. Name: `Skylax Mag`
4. URL: Choose something like `skylaxmag.blogspot.com`
5. Click **Create**
6. Note your **Blog ID** (from Settings > Publishing, or the URL: `blogger.com/blogger.g?blogID=XXXXXXX`)

### Step 1.2: Get Groq API Key (Free AI)

1. Go to **console.groq.com**
2. Sign up with Google
3. Click **API Keys** in left sidebar
4. Click **Create API Key**
5. Copy the key (starts with `gsk_...`)
6. Keep this safe — you'll need it later

---

## 2. Deploy Blogger Template

### Step 2.1: Backup Current Theme

1. Go to **blogger.com** → your blog
2. Click **Theme** in left sidebar
3. Click the **dropdown arrow** next to "Customize"
4. Click **Backup** → Download the backup file

### Step 2.2: Upload Skylax Mag Theme

1. Still in **Theme** page
2. Click the **dropdown arrow** next to "Customize"
3. Click **Switch to first generation Classic theme**
   - OR if already on classic: click **Edit HTML**
4. If using "New Theme" (XML):
   - Click **dropdown arrow** → **Backup** first
   - Then **Edit HTML**
   - Delete everything in the editor
   - Open `/fifa_blog/theme/skylax-mag.xml` on your computer
   - Copy ALL contents
   - Paste into the Blogger HTML editor
   - Click **Save** (floppy disk icon)

5. If Blogger asks about "Custom Theme" — click **Switch Anyway**

### Step 2.3: Verify Template

1. Click **View Blog** to open it
2. You should see the Skylax Mag theme with:
   - Header with "Skylax Mag" branding
   - FIFA gold/blue color scheme
   - Navigation menu
   - Featured section area
   - Sidebar
   - Footer with copyright

---

## 3. Setup Google Apps Script (Auto-Blog)

### Step 3.1: Create Apps Script Project

1. Go to **script.google.com**
2. Click **New Project**
3. Rename it: Click "Untitled project" → name it `Skylax Mag Auto-Blog`
4. You'll see `Code.gs` — delete its contents

### Step 3.2: Create All Script Files

For each file below, click **+** next to "Files" in left sidebar → **Script** → name it:

**File 1: `config`**
1. Click **+** → Script → name: `config`
2. Delete default content
3. Open `/fifa_blog/auto-blog/config.gs` on your computer
4. Copy ALL contents → paste into the `config` file
5. **Note:** Config values are stored in ScriptProperties. After first run, manage all settings from the **Settings page** in the dashboard. The `DEFAULT_CONFIG` in this file provides fallback defaults.

**File 2: `rss_fetcher`**
1. Click **+** → Script → name: `rss_fetcher`
2. Open `/fifa_blog/auto-blog/rss_fetcher.gs`
3. Copy ALL contents → paste

**File 3: `ai_rewriter`**
1. Click **+** → Script → name: `ai_rewriter`
2. Open `/fifa_blog/auto-blog/ai_rewriter.gs`
3. Copy ALL contents → paste

**File 4: `label_classifier`**
1. Click **+** → Script → name: `label_classifier`
2. Open `/fifa_blog/auto-blog/label_classifier.gs`
3. Copy ALL contents → paste

**File 5: `blogger_publisher`**
1. Click **+** → Script → name: `blogger_publisher`
2. Open `/fifa_blog/auto-blog/blogger_publisher.gs`
3. Copy ALL contents → paste
4. **IMPORTANT**: Edit `OAUTH_CONFIG` at the top of the file:
   ```javascript
   var OAUTH_CONFIG = {
     clientId: 'YOUR_CLIENT_ID.apps.googleusercontent.com',  // ← From Google Cloud Console
     clientSecret: 'YOUR_CLIENT_SECRET',                      // ← From Google Cloud Console
     scope: 'https://www.googleapis.com/auth/blogger',
     authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
     tokenUrl: 'https://oauth2.googleapis.com/token'
   };
   ```
   *(Get these credentials from Step 3.4 below)*

**File 6: `scheduler`**
1. Click **+** → Script → name: `scheduler`
2. Open `/fifa_blog/auto-blog/scheduler.gs`
3. Copy ALL contents → paste

**File 7: `logger`**
1. Click **+** → Script → name: `logger`
2. Open `/fifa_blog/auto-blog/logger.gs`
3. Copy ALL contents → paste

**File 8: `ad_analytics`**
1. Click **+** → Script → name: `ad_analytics`
2. Open `/fifa_blog/auto-blog/ad_analytics.gs`
3. Copy ALL contents → paste

**File 9: `settings`**
1. Click **+** → Script → name: `settings`
2. Open `/fifa_blog/auto-blog/settings.gs`
3. Copy ALL contents → paste

**File 10: `dashboard` (HTML)**
1. Click **+** → HTML → name: `dashboard`
2. Open `/fifa_blog/auto-blog/dashboard.html`
3. Copy ALL contents → paste

### Step 3.3: Create Google Sheet for Logs

1. Go to **sheets.google.com**
2. Click **Blank spreadsheet**
3. Rename it: `Skylax Mag Logs`
4. Copy the **Sheet ID** from the URL:
   - URL looks like: `docs.google.com/spreadsheets/d/`**`YOUR_SHEET_ID_HERE`**`/edit`
   - Copy the long string between `/d/` and `/edit`
5. Paste this ID into `config.gs` → `LOG_SHEET_ID`

### Step 3.4: Deploy as Web App

The self-contained OAuth2 flow needs a Web App deployment to handle the callback. You need this URL **before** creating OAuth credentials.

1. In Apps Script, click **Deploy** → **New deployment**
2. Click the **gear icon** → select **Web app**
3. Description: `Skylax Mag Auto-Blog OAuth`
4. Execute as: **Me**
5. Who has access: **Anyone** (needed for OAuth callback)
6. Click **Deploy**
7. **Copy the Web App URL** — it looks like:
   ```
   https://script.google.com/macros/d/YOUR_SCRIPT_ID/exec
   ```
8. Click **Done**

> **⚠️ Important:** Save this URL! You'll need it in Step 3.5.

### Step 3.5: Create Google Cloud OAuth Credentials

This is needed so Apps Script can publish to your Blogger blog.

**A. Create a Google Cloud Project:**

1. Go to **console.cloud.google.com**
2. At the top, click the **project dropdown** → **New Project**
3. Name it: `Skylax Mag`
4. Click **Create**
5. Wait for it to be created, then make sure it's selected at the top

**B. Configure OAuth Consent Screen:**

1. Go to **APIs & Services** → **OAuth consent screen**
2. User Type: **External** → Click **Create**
3. Fill in:
   - App name: `Skylax Mag`
   - User support email: Your email
   - Developer contact: Your email
4. Click **Save and Continue**
5. Scopes: Click **Add or Remove Scopes** → Add `https://www.googleapis.com/auth/blogger` → **Update** → **Save and Continue**
6. Test users: Add your Gmail address → **Save and Continue**

**C. Create OAuth Client ID:**

1. Go to **APIs & Services** → **Credentials**
2. Click **+ Create Credentials** → **OAuth client ID**
3. Application type: **Web application**
4. Name: `Skylax Mag Auto-Blog`
5. **Authorized redirect URIs**: Click **Add URI** and add **both** of these URLs:
   ```
   https://script.google.com/macros/d/YOUR_SCRIPT_ID/exec
   https://script.google.com/macros/d/YOUR_SCRIPT_ID/dev
   ```
   > **Why two URIs?** When testing from the script editor, Google uses the `/dev` URL. When running as a deployed Web App, it uses `/exec`. Both must be registered to avoid `redirect_uri_mismatch` errors.

   > **How to find your Script ID:** Look at the Apps Script URL in your browser:
   > `script.google.com/macros/d/`**`THIS_PART_IS_YOUR_ID`**`/edit`
6. Click **Create**
7. **Copy the Client ID and Client Secret** — you'll need them in Step 3.7

**D. Enable Blogger API:**

1. Still in Google Cloud Console → **APIs & Services** → **Library**
2. Search for `Blogger API v3`
3. Click on it → Click **Enable**

### Step 3.6: Remove Old OAuth2 Library (if added)

If you previously added the OAuth2 library, remove it now:

1. In Apps Script, go to **Resources** → **Libraries**
2. If you see `OAuth2` in the list, click the **X** to remove it
3. Click **OK**
4. **Note:** The new `blogger_publisher.gs` is completely self-contained — no external libraries needed.

### Step 3.7: Run OAuth Setup

1. In Apps Script editor, select `setupOAuth` from the function dropdown (top toolbar)
2. Click **Run** ▶️
3. A dialog will open with a link — **click the link** (or copy the URL from the Execution Log)
4. Authorize with your Google account:
   - Click **Review Permissions**
   - Choose your Google account
   - Click **Advanced** → **Go to Skylax Mag Auto-Blog (unsafe)**
   - Click **Allow**
5. You'll see a success page with your blog name and URL
6. Close that tab and go back to Apps Script
7. Check the Execution Log — you should see:
   ```
   === Authorization Required ===
   Click the link below to authorize:
   https://accounts.google.com/o/oauth2/v2/auth?client_id=...
   Authorization successful!
   Blog: Your Blog Name
   URL: https://your-blog.blogspot.com
   ```

### Step 3.8: Migrate Config to ScriptProperties

1. Select `migrateConfigToProperties` from function dropdown
2. Click **Run**
3. Check Execution Log — should show: `Config migrated to ScriptProperties`
4. This one-time step copies your defaults to ScriptProperties so the Settings page can read/write them dynamically

### Step 3.9: Open the Dashboard

1. Go back to your Web App URL (from Step 3.4):
   ```
   https://script.google.com/macros/d/YOUR_SCRIPT_ID/exec
   ```
2. You should see the **Skylax Mag Auto-Blog Dashboard** with two tabs:
   - **📊 Dashboard** — stats, controls, activity
   - **⚙ Settings** — all configuration
3. Click the **⚙ Settings** tab to configure everything:
   - **Blog Configuration** — Blog ID, URL, Sheet ID
   - **AI Settings** — Provider, models, API keys, prompt
   - **Schedule Settings** — Interval, max posts, dry run
   - **RSS Sources** — Add, edit, delete, toggle feeds
   - **Label Categories** — Add, edit, delete, toggle labels + keywords
4. Click **💾 Save Settings** at the bottom to save

### Step 3.10: Test the Pipeline

1. Select `testPipeline` from function dropdown
2. Click **Run**
3. Check execution log — it should show:
   - "Fetching RSS feeds..."
   - "Fetched X articles"
   - "[DRY RUN] Would publish..."
4. Check your Google Sheet — the "AutoBlog Log" tab should have entries

### Step 3.11: Setup Schedule

1. On the dashboard, click **⏰ Setup Schedule**
   - OR select `setupSchedule` from function dropdown → Run
2. This creates an automatic trigger that runs the pipeline at your configured interval
3. To change schedule: go to **⚙ Settings** → **Schedule Settings** → pick a preset → **Save** → then re-run **⏰ Setup Schedule**

### Step 3.12: Go Live

1. Go to **⚙ Settings** → **Schedule Settings**
2. Toggle **Dry Run Mode** to **OFF**
3. Click **💾 Save Settings**
4. Click **▶ Run Now** on the Dashboard tab
5. Check your blog — the first auto-post should appear!

---

## 4. Setup Smart Ad Management

### Step 4.1: Add Smart Ads JS to Your Server

The smart-ads.js file needs to be accessible via URL. Options:

**Option A: GitHub Pages (Recommended)**
1. Create a GitHub repo: `skylax-mag-ads`
2. Upload `/fifa_blog/ads/smart-ads.js` to the repo
3. Enable GitHub Pages (Settings → Pages → Source: main branch)
4. Your URL: `https://YOUR_USERNAME.github.io/skylax-mag-ads/smart-ads.js`

**Option B: Blogger Static File**
1. Go to Blogger → Settings → Other
2. Under "Grow Your Audience" → enable "Custom domain" (or use blogspot subdomain)
3. Upload `smart-ads.js` as a static file via Blogger's file manager

**Option C: Any Free Hosting**
- Upload to Netlify, Vercel, or Cloudflare Pages
- Get the direct URL to `smart-ads.js`

### Step 4.2: Update Template Script URL

1. Open the template in Blogger → Edit HTML
2. Search for: `smart-ads.js`
3. Update the script src to your hosted URL:
   ```
   s.src='https://YOUR_USERNAME.github.io/skylax-mag-ads/smart-ads.js';
   ```

### Step 4.3: Configure Ad Networks

1. Go to your blog → Click the **gear icon** (⚙️) in bottom-right corner
   - OR add `?admin=1` to your blog URL
2. The Admin Dashboard opens
3. Click **Ads** tab
4. Fill in your ad network details:

**Google AdSense:**
- Toggle: Enable AdSense
- Publisher ID: `ca-pub-XXXXXXXXXXXXXXXX`
- Auto Ads: Enable

**Monetag:**
- Toggle: Enable Monetag Push
- Push Script URL: Your Monetag push script URL

**Adsterra:**
- Toggle: Enable Adsterra
- Native Ad Code: Paste your Adsterra native banner code
- Popunder Script URL: Your Adsterra popunder URL

5. Click **Save Config** → copy the JSON

### Step 4.4: Configure Smart Ads

1. In Admin Dashboard, click **Smart Ads** tab
2. Configure settings:

**Auto-Optimization:**
- ✅ Enable Smart Ad Placement

**Ad Density:**
- Max Ads Per Page: **6 (Balanced)** ← recommended
- In-Content Frequency: **Every 3 paragraphs**

**Placement Controls:**
- ✅ Sticky Sidebar Ad
- ✅ Lazy Loading
- ✅ Exit-Intent Popup
- ✅ A/B Testing

**Revenue Tracking:**
- ✅ Enable Revenue Tracking

**Ad Slots:**
- ✅ All 8 slots enabled (Header, In-Content 1-3, Sidebar, Post Footer, Footer, Exit-Intent)

3. Click **Save Config**

### Step 4.5: Setup Ad Revenue Analytics

1. In Apps Script editor, select `initAdLogSheet` from function dropdown
2. Click **Run**
3. This creates an "Ad Revenue" tab in your Google Sheet
4. The smart-ads.js will automatically send tracking data to this sheet

---

## 5. Configure Admin Dashboard

### Step 5.1: Access the Dashboard

- **Method 1**: Click the gear icon (⚙️) in bottom-right of your blog
- **Method 2**: Add `?admin=1` to any page URL
- **Method 3**: Press `Ctrl+Shift+A` on keyboard

### Step 5.2: Theme Settings (Theme Tab)

Fill in your details:

| Field | What to Enter |
|-------|---------------|
| Site Name | Skylax Mag |
| Tagline | FIFA World Cup 2026 News |
| Logo URL | Your logo image URL (or leave empty) |
| Primary Color | #00529F (blue) |
| Accent Color | #D4AF37 (gold) |
| Posts Per Page | 8 |
| Show Breadcrumbs | ✅ On |
| Show Reading Time | ✅ On |
| Show Share Buttons | ✅ On |

Click **Save Config** → copy the JSON → paste into the Blogger Layout widget for your theme config.

### Step 5.3: Social Links (Social Tab)

| Platform | Your URL |
|----------|----------|
| Facebook | https://facebook.com/YourPage |
| Twitter/X | https://x.com/YourHandle |
| YouTube | https://youtube.com/@YourChannel |
| Instagram | https://instagram.com/YourProfile |
| Telegram | https://t.me/YourChannel |
| WhatsApp | https://wa.me/YOURNUMBER |

### Step 5.4: Footer Settings (Footer Tab)

- Copyright Text: `© 2026 Skylax Mag. All rights reserved.`
- About Text: `Your trusted source for FIFA World Cup 2026 news, transfers, and analysis.`
- Privacy Policy URL: `/p/privacy-policy.html`
- About URL: `/p/about-us.html`
- Contact URL: `/p/contact-us.html`

---

## 6. Create Blog Pages

Go to **Blogger** → **Pages** → **New Page** for each:

### Page 1: About Us
- Title: `About Us`
- Content:
```html
<h2>About Skylax Mag</h2>
<p>Skylax Mag is your premier destination for FIFA World Cup 2026 news, transfers, match reports, and in-depth analysis.</p>

<h3>Our Mission</h3>
<p>We bring you the latest football news from around the world, with a focus on the upcoming FIFA World Cup 2026 across USA, Mexico, and Canada.</p>

<h3>What We Cover</h3>
<ul>
<li><strong>Breaking News</strong> — Latest football stories as they happen</li>
<li><strong>Transfers</strong> — All the latest deals, rumors, and contract updates</li>
<li><strong>Match Reports</strong> — Detailed analysis of every major match</li>
<li><strong>World Cup 2026</strong> — Qualifiers, host cities, preparations</li>
<li><strong>Tactics</strong> — In-depth tactical analysis of teams and managers</li>
<li><strong>Players</strong> — Profiles, stats, and performance reviews</li>
</ul>

<h3>Contact</h3>
<p>For inquiries, partnerships, or advertising:</p>
<p>Email: contact@skylaxmag.com</p>
```

### Page 2: Contact Us
- Title: `Contact Us`
- Content:
```html
<h2>Contact Us</h2>
<p>Have a question, tip, or partnership inquiry? We'd love to hear from you.</p>

<h3>Email</h3>
<p>contact@skylaxmag.com</p>

<h3>Advertising</h3>
<p>For advertising opportunities, visit our <a href="/p/advertise-with-us.html">Advertise With Us</a> page.</p>

<h3>Social Media</h3>
<p>Follow us on social media for the latest updates:</p>
<ul>
<li>Twitter: @SkylaxMag</li>
<li>Facebook: /SkylaxMag</li>
<li>Instagram: @SkylaxMag</li>
</ul>
```

### Page 3: Privacy Policy
- Title: `Privacy Policy`
- Content: Use a privacy policy generator or write basic content about cookies, ad networks, and data collection.

### Page 4: Advertise With Us
- Title: `Advertise With Us`
- Content:
```html
<h2>Advertise With Skylax Mag</h2>
<p>Reach thousands of football fans with targeted advertising on Skylax Mag.</p>

<h3>Ad Placements</h3>
<ul>
<li>Header Banner (728x90)</li>
<li>In-Content Native Ads</li>
<li>Sidebar Display Ads</li>
<li>Footer Banner</li>
<li>Sponsored Articles</li>
</ul>

<h3>Contact</h3>
<p>Email: ads@skylaxmag.com</p>
```

### Page 5: Terms of Service
- Title: `Terms of Service`

---

## 7. First Post & Testing

### Step 7.1: Create a Test Post

1. Go to Blogger → **Posts** → **New Post**
2. Title: `Welcome to Skylax Mag — FIFA World Cup 2026 Coverage`
3. Write at least 5 paragraphs about the blog
4. Add labels: `news`, `world-cup-2026`
5. Click **Publish**

### Step 7.2: Verify Auto-Blog

1. In Apps Script, run `runNow()`
2. Check your blog — a new auto-generated post should appear
3. Check Google Sheet — log entry should show "published"

### Step 7.3: Verify Smart Ads

1. Open your blog in a new tab
2. Open browser console (F12 → Console)
3. Type: `SkylaxAds.getStats()`
4. You should see revenue tracking data
5. Scroll the page — ads should lazy-load
6. Check the Smart Ads admin tab for controls

### Step 7.4: Verify Admin Dashboard

1. Click the gear icon (⚙️) on your blog
2. Navigate through all tabs: Theme, Ads, Smart Ads, Social, Footer
3. Change a setting → Save → Verify it applies

---

## 8. Go Live Checklist

### Template
- [ ] Theme uploaded and working
- [ ] Header/logo displays correctly
- [ ] Navigation menu works
- [ ] Featured section shows posts
- [ ] Sidebar widgets display
- [ ] Footer copyright shows
- [ ] Mobile responsive (test on phone)
- [ ] Admin dashboard accessible (gear icon)

### Auto-Blog
- [ ] Apps Script project created
- [ ] All 10 files copied
- [ ] Blog ID configured
- [ ] Google Sheet ID configured
- [ ] Groq API key configured
- [ ] `setup()` function run successfully
- [ ] `testPipeline()` works (dry run)
- [ ] Schedule trigger created
- [ ] First real post published
- [ ] Google Sheet has log entries

### Smart Ads
- [ ] smart-ads.js hosted and accessible via URL
- [ ] Template script URL updated
- [ ] AdSense publisher ID configured
- [ ] Monetag push script configured
- [ ] Adsterra native code configured
- [ ] Smart Ads admin tab working
- [ ] Ad density set to balanced (6/page)
- [ ] Lazy loading enabled
- [ ] Exit-intent enabled
- [ ] A/B testing enabled
- [ ] Revenue tracking enabled

### Content
- [ ] About Us page created
- [ ] Contact Us page created
- [ ] Privacy Policy page created
- [ ] Advertise With Us page created
- [ ] Terms of Service page created
- [ ] Navigation menu links to all pages

### Monetization
- [ ] AdSense account approved
- [ ] AdSense publisher ID in admin
- [ ] Monetag account created
- [ ] Monetag push script in admin
- [ ] Adsterra account created
- [ ] Adsterra codes in admin

---

## Troubleshooting

### "Template won't save in Blogger"
- Make sure you're on "Classic Theme" (not "Contempo" or other modern themes)
- The XML is ~4800 lines — Blogger may take a moment to save
- If it times out, try again in a few minutes

### "Auto-blog says 'No articles found'"
- Check if RSS feeds are accessible: open the URLs in browser
- BBC Sport: `http://feeds.bbci.co.uk/sport/football/rss.xml`
- Guardian: `https://www.theguardian.com/football/rss`
- Wait a few hours if feeds are temporarily down

### "AI rewrite failed"
- Check Groq API key is valid at console.groq.com
- Free tier allows 30 requests/min — should be plenty
- System auto-falls back to Gemini if Groq fails

### "Admin dashboard doesn't open"
- Make sure you added `?admin=1` to the URL
- Or click the gear icon in bottom-right corner
- Check browser console for errors (F12)

### "Smart ads not showing"
- Check browser console for errors
- Verify smart-ads.js URL is accessible
- Check localStorage: `localStorage.getItem('skylax_ad_config')`

### "Schedule not running"
- In Apps Script, go to **Triggers** (clock icon in left sidebar)
- Verify trigger exists for `main` function
- If missing, run `setupSchedule()` again

---

## URLs Reference

| Resource | URL |
|----------|-----|
| Your Blog | https://YOUR-BLOG-NAME.blogspot.com |
| Admin Dashboard | https://YOUR-BLOG-NAME.blogspot.com/?admin=1 |
| Apps Script | https://script.google.com/home/projects |
| Google Sheet Logs | https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID |
| Groq Console | https://console.groq.com |
| Blogger Dashboard | https://www.blogger.com |

---

## Support

If you encounter issues:
1. Check the Execution Log in Apps Script for error messages
2. Check browser console (F12) for JavaScript errors
3. Verify all API keys are valid
4. Check Google Sheet for log entries
5. Test with `DRY_RUN: true` before going live
