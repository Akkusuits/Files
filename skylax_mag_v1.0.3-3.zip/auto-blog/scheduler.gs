/**
 * Skylax Mag — Scheduler & Pipeline Orchestrator
 *
 * Manages time-based triggers and runs the full auto-blogging pipeline.
 */

// ─── Pipeline Entry Points ───────────────────────────────────

// ─── Progress Tracking ───────────────────────────────────────

/**
 * Write pipeline progress to ScriptProperties for dashboard polling.
 */
function setPipelineStep(step, total, message) {
  var props = PropertiesService.getScriptProperties();
  props.setProperty('PIPELINE_PROGRESS', JSON.stringify({
    step: step,
    total: total,
    message: message,
    status: 'running',
    timestamp: new Date().toISOString()
  }));
}

/**
 * Read current pipeline progress.
 */
function getPipelineProgress() {
  var props = PropertiesService.getScriptProperties();
  return JSON.parse(props.getProperty('PIPELINE_PROGRESS') || '{}');
}

/**
 * Clear pipeline progress (called when pipeline finishes).
 */
function clearPipelineProgress() {
  PropertiesService.getScriptProperties().deleteProperty('PIPELINE_PROGRESS');
}

/**
 * Mark pipeline as complete (success or error).
 */
function setPipelineComplete(status, message) {
  var props = PropertiesService.getScriptProperties();
  var existing = JSON.parse(props.getProperty('PIPELINE_PROGRESS') || '{}');
  props.setProperty('PIPELINE_PROGRESS', JSON.stringify({
    step: existing.step || 0,
    total: existing.total || 0,
    message: message || existing.message,
    status: status,  // 'complete' or 'error'
    timestamp: new Date().toISOString()
  }));
}

// ─── Manual Publishing ───────────────────────────────────────

/**
 * Manually publish a single blog post from the dashboard.
 * @param {string} title - Post title
 * @param {string} category - Label/category key (e.g. 'news', 'transfers')
 * @param {string} content - Article body (HTML or plain text)
 * @param {string} imageUrl - Optional featured image URL
 * @param {boolean} useAI - Whether to rewrite content through AI
 * @returns {Object} { success, postUrl, title, error }
 */
function manualPublishPost(title, category, content, imageUrl, useAI) {
  Logger.log('=== MANUAL POST: ' + title + ' ===');

  if (!title || !title.trim()) {
    return { success: false, postUrl: null, title: title, error: 'Title is required' };
  }
  if (!content || !content.trim()) {
    return { success: false, postUrl: null, title: title, error: 'Content is required' };
  }

  var blogTitle = title.trim();
  var blogContent = content.trim();

  // AI Rewrite if requested
  if (useAI) {
    setPipelineStep(1, 2, 'Generating blog content with AI...');
    var article = { title: blogTitle, description: blogContent, source: 'Manual Post' };
    var rewritten = rewriteArticle(article);

    if (rewritten.success) {
      blogTitle = rewritten.title;
      blogContent = rewritten.content;
      Logger.log('AI rewritten: ' + blogTitle + ' (via ' + rewritten.provider + ')');
    } else {
      Logger.log('AI rewrite failed, using original content: ' + rewritten.error);
    }
  }

  // Format for Blogger
  var labels = category ? [category] : [];
  var formattedContent = formatForBlogger(blogContent, { thumbnail: imageUrl || '' });

  // Publish
  setPipelineStep(2, 2, 'Publishing to Blogger...');
  var result = publishPost(blogTitle, formattedContent, labels, imageUrl);

  // Log result
  logPost({
    source: 'Manual',
    originalTitle: title,
    blogTitle: blogTitle,
    url: '',
    status: result.dryRun ? 'dry-run' : (result.success ? 'published' : 'failed'),
    labels: labels,
    postUrl: result.postUrl || '',
    error: result.error || ''
  });

  setPipelineComplete(result.success ? 'complete' : 'error',
    result.success ? 'Post published!' : 'Publish failed: ' + result.error);

  Logger.log('Manual post result: ' + (result.success ? 'SUCCESS' : 'FAILED'));
  return {
    success: result.success,
    postUrl: result.postUrl || null,
    title: blogTitle,
    error: result.error || null
  };
}

/**
 * Manually update an auto-updating page from the dashboard.
 * @param {string} pageKey - Page key (schedule, standings, teams, etc.)
 * @param {string} title - Optional custom title override
 * @param {string} content - Optional custom content (if not using AI)
 * @param {boolean} useAI - Whether to generate content with AI
 * @returns {Object} { success, pageUrl, title, error }
 */
function manualPublishPage(pageKey, title, content, useAI) {
  Logger.log('=== MANUAL PAGE UPDATE: ' + pageKey + ' ===');

  if (useAI !== false) {
    // Use the page manager to generate and update
    setPipelineStep(1, 2, 'Generating page content with AI...');
    var result = triggerPageUpdate(pageKey);
    setPipelineComplete(result.success ? 'complete' : 'error',
      result.success ? 'Page updated!' : 'Update failed: ' + result.error);
    return result;
  } else if (content) {
    // Manual content — find or create page
    setPipelineStep(1, 2, 'Uploading to Blogger...');
    var config = loadConfig();
    var pageConfig = null;
    (config.PAGES || []).forEach(function(p) {
      if (p.key === pageKey) pageConfig = p;
    });

    if (!pageConfig) {
      return { success: false, pageUrl: null, title: pageKey, error: 'Page config not found' };
    }

    var pageTitle = title || pageConfig.title;
    var existing = findPageByTitle(pageTitle);
    var pageId = getPageId(pageKey) || (existing ? existing.id : null);

    var updateResult;
    if (pageId) {
      updateResult = updateBlogPage(pageId, content);
    } else {
      updateResult = createBlogPage(pageTitle, content, pageConfig.slug);
      if (updateResult.success) savePageId(pageKey, updateResult.pageId);
    }

    if (updateResult.success) {
      var props = PropertiesService.getScriptProperties();
      var lastUpdated = JSON.parse(props.getProperty('PAGES_LAST_UPDATED') || '{}');
      lastUpdated[pageKey] = new Date().toISOString();
      props.setProperty('PAGES_LAST_UPDATED', JSON.stringify(lastUpdated));
    }

    setPipelineComplete(updateResult.success ? 'complete' : 'error',
      updateResult.success ? 'Page updated!' : 'Update failed: ' + updateResult.error);
    return { success: updateResult.success, pageUrl: updateResult.pageUrl, title: pageTitle, error: updateResult.error };
  }

  return { success: false, pageUrl: null, title: pageKey, error: 'No content provided and AI disabled' };
}

// ─── Main Pipeline ───────────────────────────────────────────

/**
 * MAIN PIPELINE — Run the full auto-blogging flow.
 * This is triggered by the time-based trigger.
 */
function main() {
  Logger.log('=== Skylax Mag Auto-Blog Pipeline Started ===');
  Logger.log('Time: ' + new Date().toISOString());

  try {
    // Step 1: Check rate limit
    setPipelineStep(1, 5, 'Checking rate limit...');
    if (wasRecentPost(CONFIG.MIN_HOURS_BETWEEN_POSTS)) {
      Logger.log('Rate limited — skipping (min gap: ' + CONFIG.MIN_HOURS_BETWEEN_POSTS + 'h)');
      setPipelineComplete('complete', 'Rate limited — skipped');
      return;
    }

    // Step 2: Fetch RSS articles
    setPipelineStep(2, 5, 'Fetching RSS feeds...');
    Logger.log('Fetching RSS feeds...');
    var articles = getTopArticles(CONFIG.MAX_POSTS_PER_RUN * 3);  // Fetch extra for dedup
    Logger.log('Fetched ' + articles.length + ' articles');

    if (articles.length === 0) {
      Logger.log('No articles found — exiting');
      setPipelineComplete('complete', 'No articles found');
      return;
    }

    // Step 3: Filter out already-processed articles
    setPipelineStep(3, 5, 'Filtering already-processed articles...');
    var newArticles = [];
    for (var i = 0; i < articles.length; i++) {
      if (!isAlreadyProcessed(articles[i].link)) {
        newArticles.push(articles[i]);
      }
      if (newArticles.length >= CONFIG.MAX_POSTS_PER_RUN) break;
    }

    Logger.log('New articles to process: ' + newArticles.length);

    if (newArticles.length === 0) {
      Logger.log('All articles already processed — exiting');
      setPipelineComplete('complete', 'All articles already processed');
      return;
    }

    // Step 4: Process each article
    setPipelineStep(4, 5, 'Generating blog content with AI...');
    var published = 0;
    for (var j = 0; j < newArticles.length; j++) {
      var article = newArticles[j];
      Logger.log('Processing: ' + article.title);

      // Classify labels
      var labels = classifyArticle(article);
      Logger.log('Labels: ' + labels.join(', '));

      // AI Rewrite — add delay between articles to avoid Groq rate limits
      if (j > 0) {
        var delaySeconds = 15;  // 15s gap between articles
        Logger.log('Waiting ' + delaySeconds + 's before next AI call (rate limit protection)...');
        Utilities.sleep(delaySeconds * 1000);
      }
      var rewritten = rewriteArticle(article);
      Logger.log('AI Provider: ' + rewritten.provider + ' | Success: ' + rewritten.success);

      // Format for Blogger
      var blogContent = formatForBlogger(rewritten.content, article);

      // Publish
      setPipelineStep(5, 5, 'Publishing to Blogger...');
      var publishResult = publishPost(
        rewritten.title,
        blogContent,
        labels,
        article.thumbnail
      );

      // Log result
      logPost({
        source: article.source,
        originalTitle: article.title,
        blogTitle: rewritten.title,
        url: article.link,
        status: publishResult.dryRun ? 'dry-run' : (publishResult.success ? 'published' : 'failed'),
        labels: labels,
        postUrl: publishResult.postUrl || '',
        error: publishResult.error || ''
      });

      if (publishResult.success) {
        published++;
        Logger.log('Published: ' + rewritten.title);
      } else {
        Logger.log('Failed: ' + publishResult.error);
      }
    }

    Logger.log('=== Pipeline Complete: ' + published + '/' + newArticles.length + ' published ===');
    setPipelineComplete('complete', published + '/' + newArticles.length + ' posts published');

  } catch (e) {
    Logger.log('Pipeline error: ' + e.message);
    Logger.log('Stack: ' + e.stack);
    setPipelineComplete('error', 'Pipeline error: ' + e.message);

    logPost({
      source: 'pipeline',
      originalTitle: 'Pipeline Error',
      blogTitle: '',
      url: '',
      status: 'failed',
      labels: [],
      postUrl: '',
      error: e.message
    });
  }
}

/**
 * MANUAL RUN — Trigger the pipeline manually from the editor.
 * Same as main() but also logs that it was a manual trigger.
 */
function runNow() {
  Logger.log('=== MANUAL TRIGGER ===');
  main();
}

// ─── Schedule Management ─────────────────────────────────────

/**
 * Setup the time-based trigger based on CONFIG.ACTIVE_SCHEDULE.
 * Deletes existing triggers and creates a new one.
 */
function setupSchedule() {
  var hours = getIntervalHours();
  Logger.log('Setting up schedule: every ' + hours + ' hours');

  // Delete existing time-based triggers
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      ScriptApp.deleteTrigger(triggers[i]);
      Logger.log('Deleted old trigger');
    }
  }

  // Create new trigger
  ScriptApp.newTrigger('main')
    .timeBased()
    .everyHours(hours)
    .create();

  Logger.log('New trigger created: every ' + hours + ' hours');
  Logger.log('Next run will be approximately: ' + new Date(Date.now() + hours * 60 * 60 * 1000).toLocaleString());
}

/**
 * Remove all scheduled triggers.
 */
function removeSchedule() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      ScriptApp.deleteTrigger(triggers[i]);
      Logger.log('Removed trigger');
    }
  }
  Logger.log('All schedule triggers removed');
}

/**
 * Get info about current triggers.
 */
function getScheduleInfo() {
  var triggers = ScriptApp.getProjectTriggers();
  var info = [];

  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'main') {
      info.push({
        handler: triggers[i].getHandlerFunction(),
        type: triggers[i].getEventType(),
        nextRun: triggers[i].getNextExecutionTimestamp(),
        intervalHours: getIntervalHours()
      });
    }
  }

  if (info.length === 0) {
    Logger.log('No active schedule triggers');
  } else {
    for (var j = 0; j < info.length; j++) {
      Logger.log('Trigger: ' + info[j].handler + ' | Next: ' + info[j].nextRun + ' | Interval: ' + info[j].intervalHours + 'h');
    }
  }

  return info;
}

// ─── Setup Functions ─────────────────────────────────────────

/**
 * First-time setup wizard.
 * Run this once after configuring config.gs.
 */
function setup() {
  Logger.log('=== Skylax Mag Auto-Blog Setup ===');

  // 1. Initialize log sheet
  Logger.log('Step 1: Initializing log sheet...');
  initLogSheet();

  // 2. Setup schedule
  Logger.log('Step 2: Setting up schedule...');
  setupSchedule();

  // 3. Setup page update trigger
  Logger.log('Step 3: Setting up page update trigger...');
  setupPageUpdateTrigger(6);

  // 4. Verify config
  Logger.log('Step 4: Verifying configuration...');
  var issues = [];

  if (CONFIG.BLOG_ID === 'YOUR_BLOG_ID') {
    issues.push('BLOG_ID not configured — edit config.gs');
  }
  if (CONFIG.LOG_SHEET_ID === 'YOUR_GOOGLE_SHEET_ID') {
    issues.push('LOG_SHEET_ID not configured — edit config.gs');
  }
  if (!CONFIG.GROQ_API_KEY || CONFIG.GROQ_API_KEY === 'gsk_...') {
    issues.push('GROQ_API_KEY not configured — get free key at console.groq.com');
  }
  if (!CONFIG.GEMINI_ACCESS_TOKEN) {
    Logger.log('Warning: GEMINI_ACCESS_TOKEN not set (fallback will be unavailable)');
  }

  if (issues.length > 0) {
    Logger.log('=== Setup Incomplete — Issues Found ===');
    for (var i = 0; i < issues.length; i++) {
      Logger.log('  ✗ ' + issues[i]);
    }
    Logger.log('Edit config.gs and run setup() again');
  } else {
    Logger.log('=== Setup Complete ✓ ===');
    Logger.log('Blog: ' + CONFIG.BLOG_URL);
    Logger.log('Schedule: ' + CONFIG.ACTIVE_SCHEDULE + ' (' + getIntervalHours() + 'h)');
    Logger.log('Max posts per run: ' + CONFIG.MAX_POSTS_PER_RUN);
    Logger.log('Dry run: ' + CONFIG.DRY_RUN);
    Logger.log('');
    Logger.log('Next steps:');
    Logger.log('  1. Run testPipeline() to do a dry run');
    Logger.log('  2. Set DRY_RUN to false in config.gs');
    Logger.log('  3. The schedule will auto-publish articles');
  }
}

/**
 * Test the pipeline without publishing.
 * Temporarily enables dry run mode.
 */
function testPipeline() {
  var originalDryRun = CONFIG.DRY_RUN;
  CONFIG.DRY_RUN = true;

  Logger.log('=== TEST RUN (Dry Run Mode) ===');
  main();

  CONFIG.DRY_RUN = originalDryRun;
  Logger.log('=== Test Complete ===');
}

// ─── Dashboard Entry Point ───────────────────────────────────

/**
 * Serve the dashboard HTML page.
 * Access at: https://script.google.com/macros/s/{SCRIPT_ID}/exec
 */
function doGet(e) {
  // Route OAuth callbacks to blogger_publisher.gs
  if (e && e.parameter && e.parameter.code) {
    return doGetOAuth(e);
  }
  // Serve dashboard
  return HtmlService.createHtmlOutputFromFile('dashboard')
    .setTitle('Skylax Mag — Auto-Blog Dashboard')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * API endpoint for dashboard to get stats.
 */
function getDashboardData() {
  var props = PropertiesService.getScriptProperties();
  var lastUpdated = JSON.parse(props.getProperty('PAGES_LAST_UPDATED') || '{}');

  return {
    stats: getLogStats(),
    recentLogs: getRecentLogs(15),
    schedule: {
      active: CONFIG.ACTIVE_SCHEDULE,
      intervalHours: getIntervalHours(),
      customHours: CONFIG.SCHEDULE_CUSTOM_HOURS,
      maxPerRun: CONFIG.MAX_POSTS_PER_RUN,
      minGapHours: CONFIG.MIN_HOURS_BETWEEN_POSTS,
      dryRun: CONFIG.DRY_RUN
    },
    sources: CONFIG.SOURCES.map(function(s) {
      return { name: s.name, enabled: s.enabled, url: s.url };
    }),
    labels: Object.keys(CONFIG.LABELS).map(function(key) {
      return { name: key, enabled: CONFIG.LABELS[key].enabled };
    }),
    pages: (CONFIG.PAGES || []).map(function(p) {
      return {
        key: p.key,
        title: p.title,
        enabled: p.enabled,
        updateHours: p.updateHours,
        lastUpdated: lastUpdated[p.key] || null
      };
    }),
    labelsFull: CONFIG.LABELS
  };
}
