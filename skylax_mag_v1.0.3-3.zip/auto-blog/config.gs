/**
 * Skylax Mag — AI Auto-Blogging Configuration
 *
 * Configuration is now stored in ScriptProperties for dynamic updates.
 * DEFAULT_CONFIG provides fallback values on first run.
 * Edit via the Dashboard Settings page or run migrateConfigToProperties() once.
 */

// ─── Default Config (Fallback Values) ────────────────────────

const DEFAULT_CONFIG = {

  // ─── Blogger ───────────────────────────────────────────────
  BLOG_ID: '6275096585347699153',
  BLOG_URL: 'https://fifaclub26.blogspot.com',
  LOG_SHEET_ID: '11rMQHXkreIa9yCZASrk-OFpsBzfBWwMI7D95JJDXfJI',

  // ─── AI Provider (Groq primary, Gemini fallback) ──────────
  GROQ_API_KEY: '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',
  GROQ_MODEL: 'llama-3.1-8b-instant',
  GEMINI_ACCESS_TOKEN: 'AQ.Ab8RN6IyM4qjx-3BitVkv6kVbORCfSaf1q42AClIw5t6QrF7Mw',
  GEMINI_MODEL: 'gemini-2.5-flash',
  AI_PROVIDER: 'auto',

  // ─── Schedule ──────────────────────────────────────────────
  SCHEDULE_PRESETS: ['1hr', '2hr', '4hr', '6hr'],
  SCHEDULE_CUSTOM_HOURS: 0.5,
  ACTIVE_SCHEDULE: '1hr',

  // ─── Posting Controls ──────────────────────────────────────
  MAX_POSTS_PER_RUN: 3,
  MIN_HOURS_BETWEEN_POSTS: 0.5,
  DRY_RUN: false,

  // ─── RSS Sources ──────────────────────────────────────────
  SOURCES: [
    // Google News — FIFA World Cup 2026 (aggregates from Fox Sports, ESPN, FIFA, etc.)
    { name: 'WC2026 News',      url: 'https://news.google.com/rss/search?q=FIFA+World+Cup+2026+news&hl=en-US&gl=US&ceid=US:en',       enabled: true },
    { name: 'WC2026 Schedule',  url: 'https://news.google.com/rss/search?q=FIFA+World+Cup+2026+schedule+fixtures&hl=en-US&gl=US&ceid=US:en', enabled: true },
    { name: 'WC2026 Teams',     url: 'https://news.google.com/rss/search?q=FIFA+World+Cup+2026+teams+squads&hl=en-US&gl=US&ceid=US:en',   enabled: true },
    { name: 'WC2026 Results',   url: 'https://news.google.com/rss/search?q=FIFA+World+Cup+2026+results+scores&hl=en-US&gl=US&ceid=US:en',  enabled: true },
    { name: 'WC2026 Transfers', url: 'https://news.google.com/rss/search?q=FIFA+World+Cup+2026+transfers+signings&hl=en-US&gl=US&ceid=US:en', enabled: true },
    // General football feeds
    { name: 'BBC Sport',        url: 'http://feeds.bbci.co.uk/sport/football/rss.xml',  enabled: true },
    { name: 'Guardian',         url: 'https://www.theguardian.com/football/rss',         enabled: true },
    { name: 'Sky Sports',       url: 'http://www.skysports.com/rss/12040',              enabled: true }
  ],

  // ─── Auto-Updating Pages ─────────────────────────────────
  PAGES: [
    { key: 'schedule',  title: 'FIFA World Cup 2026 Schedule',  slug: 'world-cup-2026-schedule',  enabled: true, updateHours: 6 },
    { key: 'standings', title: 'FIFA World Cup 2026 Standings', slug: 'world-cup-2026-standings', enabled: true, updateHours: 6 },
    { key: 'teams',     title: 'FIFA World Cup 2026 Teams',     slug: 'world-cup-2026-teams',     enabled: true, updateHours: 24 },
    { key: 'stats',     title: 'FIFA World Cup 2026 Stats',     slug: 'world-cup-2026-stats',     enabled: true, updateHours: 24 },
    { key: 'results',   title: 'FIFA World Cup 2026 Results',   slug: 'world-cup-2026-results',   enabled: true, updateHours: 6 },
    { key: 'bracket',   title: 'FIFA World Cup 2026 Bracket',   slug: 'world-cup-2026-bracket',   enabled: true, updateHours: 6 }
  ],

  // ─── Label Categories ─────────────────────────────────────
  LABELS: {
    'news':            { enabled: true,  keywords: ['news','announce','report','update','reveal','declare','statement'] },
    'transfers':       { enabled: true,  keywords: ['transfer','signing','deal','bid','move','loan','contract','agree','fee','purchase'] },
    'fixtures':        { enabled: true,  keywords: ['fixture','schedule','kickoff','matchday','draw','calendar','reschedule'] },
    'teams':           { enabled: true,  keywords: ['club','team','squad','manager','coach','lineup','roster','session'] },
    'players':         { enabled: true,  keywords: ['player','striker','midfielder','goalkeeper','defender','winger','captain'] },
    'world-cup-2026':  { enabled: true,  keywords: ['world cup','fifa 2026','host city','qualification','qualifier','concacaf','uefa','copa'] },
    'match-reports':   { enabled: true,  keywords: ['match','result','score','goals','victory','defeat','win','loss','draw','stalemate'] },
    'tactics':         { enabled: true,  keywords: ['formation','tactic','strategy','pressing','counter-attack','possession','press'] },
    'standings':       { enabled: true,  keywords: ['table','standings','points','league position','ranking','top','bottom','relegation'] },
    'highlights':      { enabled: true,  keywords: ['highlight','video','goal of the week','compilation','best goals','save'] }
  },

  // ─── AI Rewrite Prompt ─────────────────────────────────────
  AI_PROMPT: `You are a senior football journalist and experienced human blogger writing for Skylax Mag, a FIFA World Cup 2026 blog.

Rewrite the following article in your own unique voice. Treat the source title and content as your niche/topic. Pick one specific, fresh angle within it and write a focused, original article for a real audience. Do not write a generic overview. Explore a specific sub-angle, question, trend, or practical situation so articles never feel repetitive.

Use HTML formatting for the output: <p> for paragraphs, <h2> for subheadings, <strong> for emphasis, and <ul>/<li> for lists.

TITLE REQUIREMENTS:
Create one unique, fresh title. It must be search-friendly and read like a real blog headline a person would click. Target a clear search intent and include words people actually type into Google. Avoid generic patterns or common phrasings. Make it feel current and specific to your chosen angle.

ARTICLE LENGTH:
Between 1000 and 1500 words. Stay strictly inside this range.

WRITING STYLE RULES:
- Create a fresh perspective — do NOT copy the original. Add your own expert insights and analysis.
- Write in an authoritative but accessible tone—the way a knowledgeable person talks to a friend who wants real answers.
- Use short and medium sentences, varying sentence length naturally. Use simple, everyday English.
- Be direct and practical. Share concrete details, statistics, examples, quotes, or specifics instead of vague statements.
- Recheck that any dates and times mentioned match the current timeline (Year 2026).
- STRICTLY FORBIDDEN: Do not use any dash characters (— or -) of any kind to join clauses. Use commas, periods, or rewrite the sentence instead.

STRUCTURE:
- Open with a hook that gets straight to the point, no long intro or "throat clearing".
- Use clear section headings (wrapped in <h2>) that match what readers are searching for.
- Keep paragraphs short (two to four sentences each, wrapped in <p>).
- Use bullet points (<ul>/<li>) only where they genuinely help.
- End with a forward-looking statement, question, or a short, useful closing that gives the reader a next step. Do not write a heavy summary that just repeats everything.

SEO REQUIREMENTS:
Naturally include the main keyword and related terms a real person would search. Place keywords in the title, the opening, at least one heading, and naturally through the body. Never stuff keywords. The article should read smoothly first and rank second.

FORBIDDEN AI WORDS AND PHRASES:
Do not use these words or phrases anywhere: delve, dive into, navigate, navigating, landscape, realm, tapestry, testament, foster, fostering, embark, journey, unleash, unlock, unlocking, harness, leverage, leveraging, robust, seamless, seamlessly, elevate, elevating, empower, empowering, game changer, game changing, cutting edge, state of the art, in today's world, in the digital age, in this digital era, ever evolving, fast paced world, when it comes to, it is important to note, it is worth noting, needless to say, at the end of the day, the bottom line, last but not least, first and foremost, that being said, moreover, furthermore, additionally, in conclusion, to sum up, in summary, ultimately, essentially, basically, arguably, notably, significantly, comprehensive, holistic, myriad, plethora, paramount, pivotal, crucial role, vital role, plays a key role, the key to, unlock the secrets, take it to the next level, look no further, whether you are a beginner or, in the realm of, a wide range of, a variety of, stand out from the crowd, the world of.

Do not write robotic transitions. Do not start sentences with the same word repeatedly. Do not use overly formal connectors or filler text.

TONE CHECK:
Before finishing, reread the text. If any sentence sounds like marketing copy or like an AI wrote it, rewrite it in plain, human language. The final article must read like a real person wrote it in one focused sitting.

OUTPUT FORMAT:
Return the title on the first line (wrapped in <h1> or plain text depending on your system's template preference).
Then the full HTML-formatted article body below it.
Nothing else. No notes, no labels, no explanation.

Title: {title}
Content: {content}`
};

// ─── Config Load/Save ────────────────────────────────────────

/**
 * Load config from ScriptProperties, falling back to DEFAULT_CONFIG.
 * Merges with defaults so new fields added later are auto-included.
 */
function loadConfig() {
  var props = PropertiesService.getScriptProperties();
  var stored = props.getProperty('CONFIG');
  if (stored) {
    try {
      var parsed = JSON.parse(stored);
      return Object.assign({}, DEFAULT_CONFIG, parsed);
    } catch(e) {
      Logger.log('Config parse error, using defaults: ' + e.message);
    }
  }
  return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
}

/**
 * Save entire config object to ScriptProperties.
 */
function saveConfig(config) {
  var props = PropertiesService.getScriptProperties();
  props.setProperty('CONFIG', JSON.stringify(config));
}

/**
 * Migrate hardcoded config to ScriptProperties.
 * ALWAYS overwrites with latest defaults to ensure SOURCES, LABELS,
 * and PAGES are current after any config.gs update.
 */
function migrateConfigToProperties() {
  saveConfig(DEFAULT_CONFIG);
  Logger.log('=== Config Force-Refreshed ===');
  Logger.log('SOURCES: ' + DEFAULT_CONFIG.SOURCES.length + ' feeds');
  Logger.log('LABELS: ' + Object.keys(DEFAULT_CONFIG.LABELS).length + ' categories');
  Logger.log('PAGES: ' + DEFAULT_CONFIG.PAGES.length + ' pages');
  Logger.log('DRY_RUN: ' + DEFAULT_CONFIG.DRY_RUN);
  Logger.log('BLOG_ID: ' + DEFAULT_CONFIG.BLOG_ID);
}

/**
 * Debug function — test each RSS feed independently.
 * Run this to see exactly which feeds work and which fail.
 */
function debugFeeds() {
  Logger.log('=== Feed Debug Test ===');
  var sources = getEnabledSources();
  Logger.log('Enabled sources: ' + sources.length);

  for (var i = 0; i < sources.length; i++) {
    var src = sources[i];
    Logger.log('');
    Logger.log('--- Testing: ' + src.name + ' ---');
    Logger.log('URL: ' + src.url);

    try {
      var response = UrlFetchApp.fetch(src.url, {
        muteHttpExceptions: true,
        followRedirects: true,
        headers: { 'User-Agent': 'SkylaxMag-AutoBlog/1.0' }
      });

      var code = response.getResponseCode();
      Logger.log('HTTP Status: ' + code);

      if (code === 200) {
        var xml = response.getContentText();
        Logger.log('Response length: ' + xml.length + ' chars');
        Logger.log('First 200 chars: ' + xml.substring(0, 200));

        var articles = parseRSS(xml, src.name);
        Logger.log('Parsed articles: ' + articles.length);

        if (articles.length > 0) {
          var recent = filterRecentArticles(articles);
          Logger.log('Within 72h: ' + recent.length);
          Logger.log('Sample title: ' + articles[0].title);
          Logger.log('Sample date: ' + articles[0].pubDate);
        }
      } else {
        Logger.log('ERROR: Non-200 response');
        Logger.log('Response body: ' + response.getContentText().substring(0, 300));
      }
    } catch (e) {
      Logger.log('FETCH ERROR: ' + e.message);
    }
  }

  Logger.log('');
  Logger.log('=== Debug Complete ===');
}

/**
 * Nuclear option — completely reset config to factory defaults.
 * Use if migrateConfigToProperties doesn't fix the issue.
 */
function forceResetConfig() {
  PropertiesService.getScriptProperties().deleteProperty('CONFIG');
  PropertiesService.getScriptProperties().deleteProperty('PAGE_IDS');
  PropertiesService.getScriptProperties().deleteProperty('PAGES_LAST_UPDATED');
  Logger.log('All config wiped from ScriptProperties');
  // Re-save defaults
  saveConfig(DEFAULT_CONFIG);
  Logger.log('Fresh defaults saved. CONFIG.SOURCES count: ' + DEFAULT_CONFIG.SOURCES.length);
}

// ─── Populate CONFIG (Backwards-Compatible) ──────────────────

/**
 * CONFIG is populated dynamically from ScriptProperties.
 * All existing code that references CONFIG.FIELD continues to work.
 */
const CONFIG = loadConfig();

// ─── Helper Functions ────────────────────────────────────────

/**
 * Get the active schedule interval in hours.
 * Returns custom hours if set, otherwise resolves preset.
 */
function getIntervalHours() {
  if (CONFIG.SCHEDULE_CUSTOM_HOURS > 0) {
    return CONFIG.SCHEDULE_CUSTOM_HOURS;
  }
  var presetMap = {
    '1hr': 1,
    '2hr': 2,
    '4hr': 4,
    '6hr': 6
  };
  return presetMap[CONFIG.ACTIVE_SCHEDULE] || 4;
}

/**
 * Get enabled labels only (where enabled: true).
 */
function getEnabledLabels() {
  var enabled = {};
  for (var label in CONFIG.LABELS) {
    if (CONFIG.LABELS[label].enabled) {
      enabled[label] = CONFIG.LABELS[label];
    }
  }
  return enabled;
}

/**
 * Get enabled RSS sources only.
 */
function getEnabledSources() {
  return CONFIG.SOURCES.filter(function(s) { return s.enabled; });
}
