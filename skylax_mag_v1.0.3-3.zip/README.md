# ⚽ Skylax Mag — FIFA World Cup 2026 Auto-Blog Platform

A complete AI-powered blogging platform for FIFA World Cup 2026 coverage. Features automated content generation, smart ad management, auto-updating pages, and a full admin dashboard — all running on Google Apps Script and Blogger.

---

## 📋 Table of Contents

- [Features](#-features)
- [Architecture](#-architecture)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [How It Works](#-how-it-works)
- [Dashboard](#-dashboard)
- [Auto-Updating Pages](#-auto-updating-pages)
- [Smart Ad Management](#-smart-ad-management)
- [Configuration](#-configuration)
- [Setup Guide](#-setup-guide)
- [API Reference](#-api-reference)
- [Troubleshooting](#-troubleshooting)
- [License](#-license)

---

## ✨ Features

### AI Auto-Blogging
- **8 RSS Feed Sources** — Google News RSS (aggregates Fox Sports, ESPN, FIFA, etc.) + BBC Sport, Guardian, Sky Sports
- **AI Content Rewriting** — Groq (primary) + Gemini (fallback) rewrite articles in unique voice
- **Smart Label Classification** — 10 football categories: news, transfers, fixtures, teams, players, world-cup-2026, match-reports, tactics, standings, highlights
- **Deduplication** — Prevents publishing the same article twice via Google Sheets logging
- **Rate Limiting** — Configurable minimum gap between posts (default: 30 minutes)
- **Dry Run Mode** — Test the full pipeline without publishing

### Dashboard
- **Progress Overlay** — Real-time step-by-step progress during pipeline runs (5 stages)
- **Manual Blog Post** — Create posts directly from the dashboard with AI rewrite toggle
- **Auto-Updating Pages** — Individual refresh controls for each data page
- **Live Stats** — Published, failed, skipped, total runs
- **Recent Activity** — Table of latest pipeline activity with status badges

### Auto-Updating Pages (6 Pages)
| Page | Content | Updates Every |
|------|---------|---------------|
| Schedule | Match dates, venues, groups, kickoff times | 6 hours |
| Standings | Group tables with points, GD, qualification status | 6 hours |
| Teams | 48 qualified teams by confederation, squads, key players | 24 hours |
| Stats | Top scorers, assists, team stats, records | 24 hours |
| Results | Latest match results, upcoming fixtures, head-to-head | 6 hours |
| Bracket | Knockout bracket R32 → Final, color-coded | 6 hours |

### Smart Ad Management
- **8 Ad Slots** — Header, In-Content (1-3), Sidebar, Post Footer, Footer, Exit-Intent
- **Multi-Network** — Google AdSense, Monetag, Adsterra support
- **Auto-Optimization** — Smart placement based on device, network speed, and user behavior
- **A/B Testing** — Automatic ad variant testing
- **Revenue Tracking** — Per-slot, per-device, per-network analytics
- **Lazy Loading** — Ads load only when visible
- **Exit-Intent Popup** — Triggered when user is about to leave

### Settings Management
- **Dynamic Config** — All settings stored in ScriptProperties (no code editing needed)
- **Blog Configuration** — Blog ID, URL, Sheet ID
- **AI Settings** — Provider selection, models, API keys with show/hide, custom prompt
- **Schedule Settings** — Radio pill presets (1hr/2hr/4hr/6hr), custom hours, max posts, min gap, dry run toggle
- **RSS Sources** — Add, edit, delete, toggle feeds
- **Label Categories** — Add, edit, delete, toggle labels + keywords
- **Auto-Updating Pages** — Enable/disable pages, update frequency
- **Danger Zone** — Reset to factory defaults with confirmation

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        BLOGGER BLOG                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ Schedule  │  │Standings │  │  Teams   │  │  Stats   │  ...     │
│  │   Page    │  │   Page   │  │   Page   │  │   Page   │          │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘          │
│       └──────────────┴──────────────┴──────────────┘               │
│                          ▲ Blogger API                              │
└──────────────────────────┼─────────────────────────────────────────┘
                           │
┌──────────────────────────┼─────────────────────────────────────────┐
│                  GOOGLE APPS SCRIPT                                  │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    page_manager.gs                           │   │
│  │  • createBlogPage()  • updateBlogPage()  • listBlogPages() │   │
│  │  • triggerPageUpdate()  • updateAllPages()                 │   │
│  └──────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌──────────────────────────┴──────────────────────────────────┐   │
│  │                    page_prompts.gs                           │   │
│  │  • getPagePrompt() — 6 specialized AI prompts              │   │
│  │  • fetchPageArticles() — topic-specific RSS fetching       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    scheduler.gs                              │   │
│  │  • main() — full pipeline orchestrator                      │   │
│  │  • manualPublishPost() — manual blog post creation          │   │
│  │  • manualPublishPage() — manual page update                 │   │
│  │  • setPipelineStep() — progress tracking                    │   │
│  │  • getDashboardData() — dashboard data bundle               │   │
│  │  • setupSchedule() — time-based trigger management          │   │
│  └──────────────────────────┬──────────────────────────────────┘   │
│                              │                                      │
│  ┌──────────────┐  ┌────────┴───────┐  ┌──────────────────────┐   │
│  │ rss_fetcher  │  │ ai_rewriter    │  │ blogger_publisher    │   │
│  │ • fetchFeed  │  │ • callGroq     │  │ • publishPost()      │   │
│  │ • parseRSS   │  │ • callGemini   │  │ • getAccessToken()   │   │
│  │ • filterBy   │  │ • formatBlog   │  │ • setupOAuth()       │   │
│  └──────────────┘  └────────────────┘  └──────────────────────┘   │
│                                                                     │
│  ┌──────────────┐  ┌────────────────┐  ┌──────────────────────┐   │
│  │label_classif │  │ logger         │  │ ad_analytics         │   │
│  │ • classify   │  │ • logPost()    │  │ • receiveAdEvents()  │   │
│  └──────────────┘  │ • isDedup()    │  │ • getAdPerformance() │   │
│                     └────────────────┘  └──────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    config.gs                                 │   │
│  │  • DEFAULT_CONFIG — all settings with defaults               │   │
│  │  • loadConfig() — reads from ScriptProperties               │   │
│  │  • saveConfig() — writes to ScriptProperties                │   │
│  │  • migrateConfigToProperties() — force-refresh              │   │
│  │  • debugFeeds() — test RSS feeds independently              │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    settings.gs                               │   │
│  │  • getConfigForUI() — masked API keys                       │   │
│  │  • saveBasicConfig() / saveAIConfig() / saveScheduleConfig()│   │
│  │  • Source CRUD: add/update/remove/toggle                    │   │
│  │  • Label CRUD: add/update/remove/toggle                     │   │
│  │  • Page config: toggle/update                                │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    dashboard.html                            │   │
│  │  • Tab bar: Dashboard | Settings                            │   │
│  │  • Progress overlay with step-by-step status                │   │
│  │  • Manual post form (New Post + Update Page modes)          │   │
│  │  • Page refresh buttons with timestamps                     │   │
│  │  • Settings form with 7 sections                            │   │
│  │  • All CSS/JS self-contained in single file                 │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  External Services                                           │   │
│  │  • Google Sheets — log storage, ad analytics                │   │
│  │  • Groq API — AI content rewriting (primary)                │   │
│  │  • Gemini API — AI content rewriting (fallback)             │   │
│  │  • Google News RSS — aggregated news feeds                  │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Hosting** | Google Blogger (free) |
| **Backend** | Google Apps Script (V8 runtime) |
| **Database** | Google Sheets + ScriptProperties |
| **AI** | Groq API (primary) + Gemini API (fallback) |
| **Auth** | OAuth2 (self-contained, no external libraries) |
| **RSS Parsing** | XmlService (Apps Script built-in) |
| **Scheduling** | Apps Script time-based triggers |
| **Frontend** | HTML/CSS/JS (self-contained dashboard) |
| **Theme** | MagSpot Premium Blogger Template (customized) |

---

## 📁 Project Structure

```
fifa_blog/
├── README.md                    ← This file
├── SETUP_GUIDE.md               ← Step-by-step deployment guide
│
├── auto-blog/                   ← Google Apps Script project (12 files)
│   ├── config.gs                ← Configuration + ScriptProperties migration
│   ├── scheduler.gs             ← Pipeline orchestrator + doGet + manual publish
│   ├── rss_fetcher.gs           ← RSS/Atom feed fetching + parsing
│   ├── ai_rewriter.gs           ← Groq + Gemini AI content rewriting
│   ├── label_classifier.gs      ← Keyword-based label assignment
│   ├── blogger_publisher.gs     ← Blogger API via OAuth2
│   ├── logger.gs                ← Google Sheet logging + dedup
│   ├── ad_analytics.gs          ← Ad revenue tracking
│   ├── settings.gs              ← Server-side CRUD for all config
│   ├── page_manager.gs          ← Blogger Pages API + auto-update
│   ├── page_prompts.gs          ← AI prompts for 6 page types
│   └── dashboard.html           ← Full dashboard UI (Dashboard + Settings)
│
├── theme/                       ← Blogger theme files
│   ├── skylax-mag.xml           ← Active theme (MagSpot-based, 4849 lines)
│   └── magspot-blogger-template-premium.xml  ← Original template backup
│
├── ads/                         ← Smart ad management
│   └── smart-ads.js             ← Client-side ad management (43 features)
│
└── 0files/                      ← Version history
    └── v1.0.2/                  ← Previous theme version backup
```

---

## ⚙️ How It Works

### Pipeline Flow

```
1. TRIGGER (scheduled/manual)
   ↓
2. RATE LIMIT CHECK
   → wasRecentPost() — skip if gap too short
   ↓
3. FETCH RSS ARTICLES
   → fetchAllArticles() — 8 sources (Google News + traditional)
   → parseRSS() — RSS 2.0 + Atom support
   ↓
4. FILTER
   → filterRecentArticles() — last 72 hours
   → isAlreadyProcessed() — dedup via Google Sheet
   ↓
5. PROCESS EACH ARTICLE
   → classifyArticle() — assign labels by keywords
   → rewriteArticle() — AI rewrite (Groq → Gemini → fallback)
   → formatForBlogger() — add thumbnail + source link
   ↓
6. PUBLISH
   → publishPost() — Blogger API v3 via OAuth2
   → logPost() — record to Google Sheet
   ↓
7. COMPLETE
   → Update dashboard stats
```

### Page Update Flow

```
1. TRIGGER (scheduled/manual)
   ↓
2. FOR EACH ENABLED PAGE
   → fetchPageArticles() — topic-specific RSS
   → getPagePrompt() — specialized AI prompt
   → generatePageContent() — AI generates HTML
   → createBlogPage() / updateBlogPage() — Blogger API
   ↓
3. RECORD TIMESTAMPS
   → Save to PAGES_LAST_UPDATED in ScriptProperties
```

### OAuth2 Flow (Self-Contained)

```
1. setupOAuth() → opens browser
2. User authorizes → Google redirects to Web App
3. doGetOAuth(e) → receives ?code= parameter
4. Exchanges code for tokens → saves to PropertiesService
5. All API calls use getAccessToken() → Bearer token
6. Auto-refresh when expired via refreshAccessToken()
```

---

## 🖥️ Dashboard

### Dashboard Tab

| Section | Description |
|---------|-------------|
| **Stats Grid** | Published, Failed, Skipped, Total Runs |
| **Controls** | Run Now, Test Run, Setup Schedule, Check Schedule |
| **Progress Overlay** | Step-by-step progress (5 stages) with spinner |
| **Manual Post** | Create posts directly with title, category, content, AI toggle |
| **Page Refresh** | Individual refresh buttons for each auto-updating page |
| **Schedule Config** | Current interval, max posts, dry run status |
| **RSS Sources** | Active feeds list |
| **Categories** | Active label categories |
| **Recent Activity** | Last 15 log entries with status badges |

### Settings Tab

| Section | Fields |
|---------|--------|
| **Blog Configuration** | Blog ID, Blog URL, Log Sheet ID |
| **AI Settings** | Provider (auto/groq/gemini), Groq model, Gemini model, API keys (with show/hide), AI prompt with `{title}` and `{content}` placeholders |
| **Schedule Settings** | Radio pills (1hr/2hr/4hr/6hr), custom hours, max posts per run, min gap between posts, dry run toggle |
| **RSS Sources** | List with toggle/edit/delete, inline add form |
| **Label Categories** | List with toggle/edit/delete/keyword editing, inline add form |
| **Auto-Updating Pages** | List with toggle, update hours, "Update Now" button per page |
| **Danger Zone** | Reset to defaults with confirmation modal |

### Dashboard Features

- **Loading Overlay** — Full-screen overlay with animated spinner showing pipeline progress (1/5 through 5/5) with checkmarks for completed steps
- **Manual Blog Post** — Two modes: "New Blog Post" (publish to blog) and "Update Page" (update existing auto-updating pages). Each mode has title, category/page selector, content textarea, image URL (post mode only), AI rewrite toggle, and publish/update button
- **Page Refresh Buttons** — Individual refresh for each auto-updating page with last-updated timestamps (relative time: "2h ago", "6h ago"), spinner while updating, success/failure toast notifications
- **Toast Notifications** — Green for success, red for error, blue for info. Auto-dismiss after 3 seconds
- **Modal Confirmations** — Used for destructive actions (delete source, delete label, reset to defaults)
- **Tab Navigation** — Dashboard and Settings tabs with instant switching (no page reload)

---

## 📄 Auto-Updating Pages

6 pages that automatically update with the latest FIFA World Cup 2026 data using AI-generated content.

### Page List

| Key | Title | Slug | Update Frequency |
|-----|-------|------|------------------|
| `schedule` | FIFA World Cup 2026 Schedule | `world-cup-2026-schedule` | Every 6 hours |
| `standings` | FIFA World Cup 2026 Standings | `world-cup-2026-standings` | Every 6 hours |
| `teams` | FIFA World Cup 2026 Teams | `world-cup-2026-teams` | Every 24 hours |
| `stats` | FIFA World Cup 2026 Stats | `world-cup-2026-stats` | Every 24 hours |
| `results` | FIFA World Cup 2026 Results | `world-cup-2026-results` | Every 6 hours |
| `bracket` | FIFA World Cup 2026 Bracket | `world-cup-2026-bracket` | Every 6 hours |

### How Pages Work

1. **Data Collection** — Each page fetches topic-specific RSS articles from Google News
2. **AI Generation** — Specialized prompts instruct AI to extract structured data and format as HTML tables/lists
3. **Blogger Update** — Content is published via the Blogger Pages API (same OAuth as blog posts)
4. **Scheduling** — Separate trigger (default: every 6 hours) runs `updateAllPages()`
5. **Dashboard Control** — Individual refresh buttons + toggle enable/disable per page

### Theme Integration

The 6 pages are linked in the blog theme's header navigation bar:
```
Home | Schedule | Standings | Teams | Stats | Results | Bracket
```

---

## 📢 Smart Ad Management

### Features (43 total)

- **8 Ad Slots** — Header Banner, In-Content (1-3), Sidebar, Post Footer, Footer, Exit-Intent
- **Multi-Network** — Google AdSense, Monetag, Adsterra
- **Auto-Optimization** — Smart placement based on viewport, device, network speed
- **A/B Testing** — Automatic variant rotation with conversion tracking
- **Revenue Tracking** — Per-slot, per-device, per-network analytics
- **Lazy Loading** — Ads load only when visible in viewport
- **Exit-Intent Popup** — Triggered when cursor leaves viewport
- **Responsive Ads** — Auto-resize for mobile/tablet/desktop
- **Ad Density Control** — Max ads per page, frequency capping
- **Cookie Consent** — GDPR-compliant cookie consent banner
- **Admin Dashboard** — Full admin panel accessible from blog (gear icon)

### Ad Slots

| Slot | Position | Default Size |
|------|----------|-------------|
| `header` | Above navigation | 728×90 (leaderboard) |
| `in-content-1` | After 2nd paragraph | Responsive |
| `in-content-2` | After 4th paragraph | Responsive |
| `in-content-3` | After 6th paragraph | Responsive |
| `sidebar` | Right sidebar sticky | 300×250 |
| `post-footer` | End of article | 728×90 |
| `footer` | Site footer | 728×90 |
| `exit-intent` | On exit | Responsive |

---

## ⚙️ Configuration

### Config Storage

All configuration is stored in **ScriptProperties** (not hardcoded). The `config.gs` file provides `DEFAULT_CONFIG` as fallback defaults.

```
loadConfig() → reads ScriptProperties → merges with DEFAULT_CONFIG → returns CONFIG
saveConfig() → writes entire config as JSON to ScriptProperties
```

### Config Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `BLOG_ID` | string | `6275096585347699153` | Blogger Blog ID |
| `BLOG_URL` | string | `https://fifaclub26.blogspot.com` | Blog URL |
| `LOG_SHEET_ID` | string | `11rMQHXre...` | Google Sheet ID for logs |
| `GROQ_API_KEY` | string | `gsk_...` | Groq API key |
| `GROQ_MODEL` | string | `llama-3.1-8b-instant` | Groq model |
| `GEMINI_API_KEY` | string | `AQ.Ab8...` | Gemini API key |
| `GEMINI_MODEL` | string | `gemini-3.5-flash` | Gemini model |
| `AI_PROVIDER` | string | `auto` | `auto` / `groq` / `gemini` |
| `ACTIVE_SCHEDULE` | string | `1hr` | `1hr` / `2hr` / `4hr` / `6hr` |
| `SCHEDULE_CUSTOM_HOURS` | number | `0.5` | Custom hours (0 = use preset) |
| `MAX_POSTS_PER_RUN` | number | `3` | Max articles per pipeline run |
| `MIN_HOURS_BETWEEN_POSTS` | number | `0.5` | Min gap between posts |
| `DRY_RUN` | boolean | `false` | Test mode |
| `SOURCES` | array | 8 feeds | RSS feed sources |
| `LABELS` | object | 10 categories | Label classification |
| `PAGES` | array | 6 pages | Auto-updating pages |

### Config Migration

After updating `config.gs`, run `migrateConfigToProperties` to push changes:
- Scalar values (BLOG_ID, DRY_RUN, etc.) are preserved from existing config
- Arrays (SOURCES, LABELS, PAGES) are overwritten with latest defaults

---

## 🚀 Setup Guide

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for the complete step-by-step deployment guide.

### Quick Start

1. **Create Blogger blog** at blogger.com
2. **Create Apps Script project** at script.google.com
3. **Copy all 12 files** from `auto-blog/` to Apps Script
4. **Deploy as Web App** → get the URL
5. **Create Google Cloud OAuth** → get Client ID + Secret
6. **Run `setupOAuth`** → authorize with Google
7. **Run `migrateConfigToProperties`** → save config
8. **Run `debugFeeds`** → verify RSS feeds work
9. **Run `initPages`** → create 6 auto-updating pages
10. **Open dashboard** → start posting!

### Files to Copy to Apps Script (12 files)

| # | File | Type |
|---|------|------|
| 1 | `config` | Script |
| 2 | `rss_fetcher` | Script |
| 3 | `ai_rewriter` | Script |
| 4 | `label_classifier` | Script |
| 5 | `blogger_publisher` | Script |
| 6 | `scheduler` | Script |
| 7 | `logger` | Script |
| 8 | `ad_analytics` | Script |
| 9 | `settings` | Script |
| 10 | `page_prompts` | Script |
| 11 | `page_manager` | Script |
| 12 | `dashboard` | HTML |

---

## 📡 API Reference

### Server-Side Functions (Google Apps Script)

#### Pipeline
| Function | File | Description |
|----------|------|-------------|
| `main()` | scheduler.gs | Full pipeline: fetch → dedup → classify → rewrite → publish → log |
| `testPipeline()` | scheduler.gs | Dry-run pipeline (DRY_RUN forced true) |
| `runNow()` | scheduler.gs | Manual trigger with log marker |
| `setupSchedule()` | scheduler.gs | Create/update time-based trigger |
| `getScheduleInfo()` | scheduler.gs | Return trigger info |

#### Progress Tracking
| Function | File | Description |
|----------|------|-------------|
| `setPipelineStep(step, total, message)` | scheduler.gs | Write progress to ScriptProperties |
| `getPipelineProgress()` | scheduler.gs | Read current progress |
| `clearPipelineProgress()` | scheduler.gs | Delete progress data |
| `setPipelineComplete(status, message)` | scheduler.gs | Mark pipeline finished |

#### Manual Publishing
| Function | File | Description |
|----------|------|-------------|
| `manualPublishPost(title, category, content, imageUrl, useAI)` | scheduler.gs | Publish single blog post |
| `manualPublishPage(pageKey, title, content, useAI)` | scheduler.gs | Update existing auto-updating page |

#### Dashboard Data
| Function | File | Description |
|----------|------|-------------|
| `getDashboardData()` | scheduler.gs | Stats + logs + schedule + sources + labels + pages |
| `getConfigForUI()` | settings.gs | Config with masked API keys |

#### Settings CRUD
| Function | File | Description |
|----------|------|-------------|
| `saveBasicConfig(data)` | settings.gs | Save Blog ID, URL, Sheet ID |
| `saveAIConfig(data)` | settings.gs | Save AI provider, models, keys, prompt |
| `saveScheduleConfig(data)` | settings.gs | Save schedule, posts, gap, dry run |
| `addSource(name, url)` | settings.gs | Add RSS source |
| `updateSource(index, name, url, enabled)` | settings.gs | Update RSS source |
| `removeSource(index)` | settings.gs | Delete RSS source |
| `toggleSource(index)` | settings.gs | Toggle RSS source |
| `addLabel(name, keywords)` | settings.gs | Add label category |
| `updateLabel(name, data)` | settings.gs | Update label |
| `removeLabel(name)` | settings.gs | Delete label |
| `toggleLabel(name)` | settings.gs | Toggle label |
| `resetConfig()` | settings.gs | Reset to DEFAULT_CONFIG |

#### Page Management
| Function | File | Description |
|----------|------|-------------|
| `initPages()` | page_manager.gs | Create all 6 pages on blog |
| `updateAllPages()` | page_manager.gs | Update all enabled pages |
| `updateSinglePage(pageKey)` | page_manager.gs | Update one page |
| `triggerPageUpdate(pageKey)` | page_manager.gs | Manual trigger from dashboard |
| `listBlogPages()` | page_manager.gs | List all blog pages via API |
| `findPageByTitle(title)` | page_manager.gs | Find page by title |
| `createBlogPage(title, html, slug)` | page_manager.gs | Create new page |
| `updateBlogPage(pageId, html)` | page_manager.gs | Update existing page |
| `setupPageUpdateTrigger(hours)` | page_manager.gs | Create page update trigger |

#### RSS & AI
| Function | File | Description |
|----------|------|-------------|
| `fetchAllArticles()` | rss_fetcher.gs | Fetch all enabled sources |
| `getTopArticles(count)` | rss_fetcher.gs | Fetch + filter + sort + limit |
| `fetchFeed(source)` | rss_fetcher.gs | Fetch single RSS URL |
| `parseRSS(xml, name)` | rss_fetcher.gs | Parse RSS 2.0 or Atom |
| `rewriteArticle(article)` | ai_rewriter.gs | AI rewrite (Groq → Gemini → fallback) |
| `callGroq(prompt)` | ai_rewriter.gs | Groq API call |
| `callGemini(prompt)` | ai_rewriter.gs | Gemini API call |
| `classifyArticle(article)` | label_classifier.gs | Assign labels by keywords |

#### Config & Debug
| Function | File | Description |
|----------|------|-------------|
| `loadConfig()` | config.gs | Read config from ScriptProperties |
| `saveConfig(config)` | config.gs | Write config to ScriptProperties |
| `migrateConfigToProperties()` | config.gs | Force-refresh all config |
| `debugFeeds()` | config.gs | Test each RSS feed independently |
| `forceResetConfig()` | config.gs | Nuclear reset (wipe + re-save defaults) |

### Client-Side Functions (dashboard.html)

#### Dashboard Tab
| Function | Description |
|----------|-------------|
| `runNow()` | Run full pipeline with progress overlay |
| `testRun()` | Run dry-run pipeline with progress overlay |
| `setupSchedule()` | Create/update schedule trigger |
| `getScheduleInfo()` | Log schedule info |
| `showProgressOverlay(title)` | Show loading overlay with spinner |
| `hideProgressOverlay()` | Hide loading overlay |
| `pollProgress()` | Poll server for pipeline status |
| `updateProgressUI(status)` | Update step indicators |
| `publishManualPost()` | Publish manual blog post |
| `publishManualPage()` | Update manual page |
| `switchPostMode(mode)` | Toggle between Post/Page mode |
| `renderPageRefreshList(pages)` | Render page refresh buttons |
| `refreshSinglePage(key, btn)` | Refresh one page |
| `refreshAllPages()` | Refresh all pages with overlay |

#### Settings Tab
| Function | Description |
|----------|-------------|
| `loadSettings()` | Load config for settings UI |
| `renderSettings(config)` | Populate all form fields |
| `saveAllSettings()` | Save all sections sequentially |
| `renderSources(sources)` | Render RSS source list |
| `renderLabels(labels)` | Render label category list |
| `renderPages(pages)` | Render page config list |
| `toggleSource(index)` | Toggle source enable/disable |
| `addNewSource()` | Add new RSS source |
| `editSource(index)` | Edit source inline |
| `removeSource(index)` | Remove source |
| `toggleLabel(name)` | Toggle label enable/disable |
| `addNewLabel()` | Add new label category |
| `editLabel(name)` | Edit label keywords inline |
| `removeLabel(name)` | Remove label |
| `togglePage(key)` | Toggle page enable/disable |
| `updatePageNow(key)` | Manual page refresh |
| `updateAllPagesNow()` | Refresh all pages |
| `setupPageTrigger()` | Create page update trigger |
| `resetToDefaults()` | Reset config with confirmation |
| `showModal(title, message, onConfirm)` | Show confirmation modal |
| `toggleKeyVisibility(inputId)` | Show/hide API key |
| `switchTab(tabName)` | Switch between Dashboard/Settings tabs |

---

## 🔧 Troubleshooting

### "No articles found"
- Run `debugFeeds` to test each RSS feed individually
- Check HTTP status codes — feeds returning 403 may be blocked
- Verify feeds are accessible in a browser
- The `filterRecentArticles()` function keeps only articles from the last 72 hours

### "Rate limited"
- The pipeline checks `MIN_HOURS_BETWEEN_POSTS` before processing
- Default: 30 minutes — reduce this in Settings or wait
- The `wasRecentPost()` function checks the last 10 log entries

### "OAuth error" / "Not authorized"
- Run `setupOAuth` to re-authorize
- Verify redirect URIs include both `/exec` and `/dev`
- Check that Blogger API v3 is enabled in Google Cloud Console

### "AI rewrite failed"
- Check Groq API key is valid at console.groq.com
- Free tier allows 30 requests/min
- System auto-falls back to Gemini if Groq fails
- If both fail, raw content is published as-is

### "Dashboard shows stale data"
- Click the reload button on the Settings tab
- Or refresh the page entirely
- Config is loaded on page load — changes from other sessions won't auto-update

### "Progress overlay stuck"
- The overlay polls every 2 seconds — it may take a moment to complete
- If stuck for >2 minutes, refresh the page
- Check Execution Log in Apps Script for errors

### "Config not updating"
- Run `migrateConfigToProperties` after any `config.gs` changes
- The merge only adds new scalar fields — arrays are force-overwritten
- Use `forceResetConfig` for a complete wipe and re-save

### "Pages not showing in blog header"
- Verify the theme XML includes the `.wc2026-nav` section
- Check that page URLs are correct (format: `p/world-cup-2026-schedule.html`)
- Pages must be created first via `initPages` before links work

---

## 📊 Monitoring

### Google Sheets Logging

Every pipeline run logs to the "AutoBlog Log" tab:
| Column | Description |
|--------|-------------|
| Timestamp | When the post was processed |
| Source | RSS feed name (e.g., "WC2026 Schedule") |
| Original Title | Article title from RSS |
| Blog Title | AI-rewritten title |
| Original URL | Source article link |
| Status | `published` / `failed` / `skipped` / `dry-run` |
| Labels | Assigned category labels |
| Blog Post URL | Published post link (if successful) |
| Error | Error message (if failed) |

### Execution Log

Check the Apps Script Execution Log for:
- Pipeline progress (step-by-step)
- Feed fetch results
- AI rewrite provider and success/failure
- Publish success/failure with post URLs
- Page update status

---

## 🔐 Security Notes

- **API Keys** are stored in ScriptProperties (not in source code defaults)
- **Dashboard** requires Web App deployment — anyone with the URL can access
- **OAuth tokens** are stored in UserProperties (per-user)
- **DRY_RUN** should be `false` only when ready to publish
- Consider adding authentication to the Web App if needed

---

## 📝 Changelog

### v1.0.3 (2026-06-22) — Latest
- Added manual blog post section with AI rewrite toggle (New Post + Update Page modes)
- Added page refresh buttons with individual controls for each auto-updating page
- Added progress overlay with step-by-step pipeline status (5 stages)
- Added 6 auto-updating Blogger pages (schedule, standings, teams, stats, results, bracket)
- Added Google News RSS feeds (5 topic-specific feeds aggregating Fox Sports, ESPN, FIFA)
- Migrated config to ScriptProperties for dynamic updates via dashboard Settings
- Added Settings page with full CRUD for all config, sources, labels, pages
- Added header navigation bar with page links below the site title
- Added `debugFeeds()` function to test each RSS feed independently
- Added `forceResetConfig()` function for complete config wipe and re-save
- Added `manualPublishPost()` and `manualPublishPage()` server functions
- Added progress tracking functions (`setPipelineStep`, `getPipelineProgress`, `setPipelineComplete`)
- Added pages data to `getDashboardData()` response
- Fixed RSS parser bug — items are inside `<channel>`, not directly under `<rss>`
- Fixed dashboard labels rendering as numeric indices instead of names
- Fixed duplicate `doGet` conflict between scheduler.gs and blogger_publisher.gs
- Fixed config migration not refreshing arrays (SOURCES, LABELS, PAGES) on re-run
- Updated `filterRecentArticles()` window from 24h to 72h for better coverage
- Updated `main()` pipeline to report progress at each stage
- Updated `updateSinglePage()` to report progress during page updates
- Updated setup guide with all new steps (3.9-3.15)

### v1.0.2 (2026-06-19)
- Implemented smart ad management system (43 features)
- Added admin dashboard (Theme, Ads, Smart Ads, Social, Footer tabs)
- Added ad revenue tracking with per-slot, per-device, per-network analytics
- Added A/B testing for ad variants
- Added lazy loading for ads
- Added exit-intent popup
- Added cookie consent banner (GDPR)
- Added responsive ad sizing for mobile/tablet/desktop
- Added ad density control and frequency capping
- Added Adsterra network support
- Added Monetag push notification support
- Created ad_analytics.gs for Google Sheets logging
- Updated theme with ad slot positions (8 slots)

### v1.0.1 (2026-06-19)
- Implemented self-contained OAuth2 flow (no external libraries required)
- Added `setupOAuth()` for browser-based authorization
- Added `doGetOAuth()` callback handler for OAuth redirects
- Added `refreshAccessToken()` for automatic token renewal
- Added `disconnectOAuth()` for token cleanup
- Added Blogger API v3 integration for post publishing
- Added `publishPost()` function with featured image support
- Added `getRecentPosts()` for deduplication
- Added `getBlogInfo()` for blog metadata
- Created scheduler.gs with full pipeline orchestrator
- Created rss_fetcher.gs with RSS 2.0 and Atom parsing
- Created ai_rewriter.gs with Groq and Gemini AI rewriting
- Created label_classifier.gs with keyword-based classification
- Created logger.gs with Google Sheets logging and dedup
- Created config.gs with DEFAULT_CONFIG and helper functions
- Created dashboard.html with Stats Grid, Controls, Schedule, Sources, Labels, Activity

### v1.0.0 (2026-06-17)
- Initial release — 7 development phases complete
- MagSpot Premium Blogger template customized for FIFA World Cup 2026
- Branding: header, logo, colors, typography
- Ad placement zones configured
- Admin panel integration
- Static pages (About, Contact, Privacy, Advertise, Terms)
- Content structure and navigation
- AI auto-blog pipeline (basic RSS → publish flow)
- Smart ad management foundation

---

## 📄 License

This project is proprietary software developed for Skylax Mag. All rights reserved.

---

## 🤝 Support

For issues or questions:
1. Check the [SETUP_GUIDE.md](SETUP_GUIDE.md) for deployment steps
2. Check the [Troubleshooting](#-troubleshooting) section above
3. Review the Execution Log in Apps Script
4. Check the Google Sheet for log entries
5. Test with `DRY_RUN: true` before going live
